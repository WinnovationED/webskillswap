import React, { createContext, useContext, useState, useEffect } from 'react';
import { useAuth } from './AuthContext';

const ChatContext = createContext();

export function useChat() {
  return useContext(ChatContext);
}

export function ChatProvider({ children, socket }) {
  const [chatRooms, setChatRooms] = useState([]);
  const [activeRoom, setActiveRoom] = useState(null);
  const [messages, setMessages] = useState([]);
  const [unreadCounts, setUnreadCounts] = useState({});
  const { currentUser } = useAuth();

  useEffect(() => {
    if (currentUser && socket) {
      socket.auth = { token: currentUser.token };
      socket.connect();

      socket.on('connect', () => {
        console.log('Connected to chat server');
      });

      socket.on('new_message', handleNewMessage);
      socket.on('message_read', handleMessageRead);

      return () => {
        socket.off('new_message', handleNewMessage);
        socket.off('message_read', handleMessageRead);
        socket.disconnect();
      };
    }
  }, [currentUser, socket]);

  useEffect(() => {
    if (currentUser) {
      fetchChatRooms();
      fetchUnreadCounts();
    }
  }, [currentUser]);

  const fetchChatRooms = async () => {
    try {
      const response = await fetch('/api/chat/rooms', {
        headers: {
          'Authorization': `Bearer ${currentUser.token}`
        }
      });
      const data = await response.json();
      if (response.ok) {
        setChatRooms(data);
      }
    } catch (error) {
      console.error('Error fetching chat rooms:', error);
    }
  };

  const fetchMessages = async (roomId) => {
    try {
      const response = await fetch(`/api/chat/rooms/${roomId}/messages`, {
        headers: {
          'Authorization': `Bearer ${currentUser.token}`
        }
      });
      const data = await response.json();
      if (response.ok) {
        setMessages(data);
        markRoomAsRead(roomId);
      }
    } catch (error) {
      console.error('Error fetching messages:', error);
    }
  };

  const fetchUnreadCounts = async () => {
    try {
      const response = await fetch('/api/chat/unread-counts', {
        headers: {
          'Authorization': `Bearer ${currentUser.token}`
        }
      });
      const data = await response.json();
      if (response.ok) {
        const counts = {};
        data.forEach(({ chatRoomId, unreadCount }) => {
          counts[chatRoomId] = unreadCount;
        });
        setUnreadCounts(counts);
      }
    } catch (error) {
      console.error('Error fetching unread counts:', error);
    }
  };

  const sendMessage = async (roomId, content, messageType = 'text', metadata = {}) => {
    try {
      if (!socket?.connected) {
        throw new Error('Not connected to chat server');
      }

      socket.emit('send_message', {
        roomId,
        content,
        messageType,
        metadata
      });

      // Optimistically add message to state
      const newMessage = {
        _id: Date.now().toString(),
        chatRoom: roomId,
        sender: currentUser._id,
        content,
        messageType,
        metadata,
        createdAt: new Date().toISOString(),
        pending: true
      };

      setMessages(prev => [...prev, newMessage]);
    } catch (error) {
      console.error('Error sending message:', error);
      throw error;
    }
  };

  const markRoomAsRead = async (roomId) => {
    try {
      const response = await fetch(`/api/chat/rooms/${roomId}/read`, {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${currentUser.token}`
        }
      });
      if (response.ok) {
        setUnreadCounts(prev => ({
          ...prev,
          [roomId]: 0
        }));
        socket.emit('mark_read', { roomId });
      }
    } catch (error) {
      console.error('Error marking room as read:', error);
    }
  };

  const handleNewMessage = (data) => {
    const { chatRoomId, message } = data;

    // Update messages if we're in the active room
    if (activeRoom?._id === chatRoomId) {
      setMessages(prev => [...prev, message]);
      markRoomAsRead(chatRoomId);
    } else {
      // Update unread count
      setUnreadCounts(prev => ({
        ...prev,
        [chatRoomId]: (prev[chatRoomId] || 0) + 1
      }));
    }

    // Update chat room's last message
    setChatRooms(prev =>
      prev.map(room =>
        room._id === chatRoomId
          ? {
              ...room,
              lastMessage: {
                content: message.content,
                sender: message.sender,
                createdAt: message.createdAt
              }
            }
          : room
      )
    );
  };

  const handleMessageRead = (data) => {
    const { roomId, userId } = data;
    if (userId !== currentUser._id) {
      setMessages(prev =>
        prev.map(message =>
          message.chatRoom === roomId
            ? {
                ...message,
                readBy: [...(message.readBy || []), { user: userId, readAt: new Date() }]
              }
            : message
        )
      );
    }
  };

  const value = {
    socket,
    chatRooms,
    activeRoom,
    setActiveRoom,
    messages,
    unreadCounts,
    sendMessage,
    fetchMessages,
    markRoomAsRead,
    fetchChatRooms
  };

  return (
    <ChatContext.Provider value={value}>
      {children}
    </ChatContext.Provider>
  );
}
