import React, { useState, useEffect } from 'react';
import {
  Container,
  Typography,
  Grid,
  Card,
  CardContent,
  CardActions,
  Button,
  Box,
  Chip,
  Rating,
  Avatar,
  CircularProgress,
  Alert,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
} from '@mui/material';
import { useAuth } from '../contexts/AuthContext';
import api from '../utils/api';

function SkillMatches() {
  const { currentUser } = useAuth();
  const [matches, setMatches] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [selectedMatch, setSelectedMatch] = useState(null);
  const [confirmDialogOpen, setConfirmDialogOpen] = useState(false);

  useEffect(() => {
    if (currentUser) {
      fetchMatches();
    }
  }, [currentUser]);

  const fetchMatches = async () => {
    try {
      setLoading(true);
      const response = await api.get('/api/matches/suggestions');
      setMatches(response.data);
      setError('');
    } catch (err) {
      setError('Failed to load matches. Please try again later.');
      console.error('Error fetching matches:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleMatchRequest = async (match) => {
    setSelectedMatch(match);
    setConfirmDialogOpen(true);
  };

  const confirmMatchRequest = async () => {
    try {
      await api.post('/api/matches', {
        teacherId: selectedMatch.teacher._id,
        skillId: selectedMatch.teachingSkill._id
      });
      
      // Remove the match from suggestions
      setMatches(matches.filter(m => 
        m.teachingSkill._id !== selectedMatch.teachingSkill._id ||
        m.teacher._id !== selectedMatch.teacher._id
      ));
      
      setConfirmDialogOpen(false);
      setSelectedMatch(null);
    } catch (err) {
      setError('Failed to send match request. Please try again.');
      console.error('Error creating match:', err);
    }
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '80vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Container maxWidth="lg" sx={{ py: 4 }} tabIndex="-1">
      <Typography variant="h4" gutterBottom component="h1">
        Skill Matches
      </Typography>

      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}

      {matches.length === 0 ? (
        <Alert severity="info">
          No matches found. Try adding more skills you want to learn!
        </Alert>
      ) : (
        <Grid container spacing={3}>
          {matches.map((match, index) => (
            <Grid item xs={12} md={6} key={index}>
              <Card>
                <CardContent>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                    <Avatar
                      src={match.teacher.profileImage}
                      alt={match.teacher.name}
                      sx={{ width: 56, height: 56, mr: 2 }}
                    />
                    <Box>
                      <Typography variant="h6">
                        {match.teacher.name}
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        Teaching {match.teachingSkill.skillName}
                      </Typography>
                    </Box>
                  </Box>

                  <Typography variant="subtitle1" gutterBottom>
                    Match Score: {match.score.toFixed(2)}
                  </Typography>

                  <Box sx={{ mb: 2 }}>
                    <Typography variant="subtitle2" gutterBottom>
                      Common Availability:
                    </Typography>
                    <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                      {match.teachingSkill.availability.weekdays.map((day) => (
                        <Chip
                          key={day}
                          label={day}
                          size="small"
                          color={match.commonDays.includes(day) ? "primary" : "default"}
                        />
                      ))}
                    </Box>
                  </Box>

                  <Box sx={{ mb: 2 }}>
                    <Typography variant="subtitle2" gutterBottom>
                      Teacher's Rating:
                    </Typography>
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      <Rating
                        value={match.teachingSkill.averageRating || 0}
                        precision={0.5}
                        readOnly
                      />
                      <Typography variant="body2" color="text.secondary" sx={{ ml: 1 }}>
                        ({match.teachingSkill.ratings?.length || 0} ratings)
                      </Typography>
                    </Box>
                  </Box>

                  {match.commonTags > 0 && (
                    <Box>
                      <Typography variant="subtitle2" gutterBottom>
                        Common Interests:
                      </Typography>
                      <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                        {match.teachingSkill.tags.map((tag) => (
                          <Chip
                            key={tag}
                            label={tag}
                            size="small"
                            color={match.learningSkill.tags.includes(tag) ? "primary" : "default"}
                          />
                        ))}
                      </Box>
                    </Box>
                  )}
                </CardContent>
                <CardActions>
                  <Button 
                    variant="contained" 
                    color="primary"
                    onClick={() => handleMatchRequest(match)}
                    aria-label={`Request to learn ${match.teachingSkill.skillName} from ${match.teacher.name}`}
                  >
                    Request to Learn
                  </Button>
                </CardActions>
              </Card>
            </Grid>
          ))}
        </Grid>
      )}

      {/* Confirmation Dialog */}
      <Dialog
        open={confirmDialogOpen}
        onClose={() => setConfirmDialogOpen(false)}
        aria-labelledby="confirm-match-title"
      >
        <DialogTitle id="confirm-match-title">Confirm Match Request</DialogTitle>
        <DialogContent>
          <Typography>
            Would you like to send a match request to learn{' '}
            {selectedMatch?.teachingSkill.skillName} from{' '}
            {selectedMatch?.teacher.name}?
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button 
            onClick={() => setConfirmDialogOpen(false)}
            aria-label="Cancel match request"
          >
            Cancel
          </Button>
          <Button 
            onClick={confirmMatchRequest} 
            variant="contained" 
            color="primary"
            aria-label="Send match request"
          >
            Send Request
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
}

export default SkillMatches;
