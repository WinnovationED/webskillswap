import React, { useState } from 'react';
import {
  Box,
  Container,
  Grid,
  Card,
  CardContent,
  Typography,
  Avatar,
  Button,
  TextField,
  Divider,
  Chip,
  IconButton,
  useTheme,
  Tab,
  Tabs,
  Rating,
  Stack,
} from '@mui/material';
import EditIcon from '@mui/icons-material/Edit';
import SaveIcon from '@mui/icons-material/Save';
import CancelIcon from '@mui/icons-material/Cancel';
import PhotoCameraIcon from '@mui/icons-material/PhotoCamera';
import SchoolIcon from '@mui/icons-material/School';
import WorkIcon from '@mui/icons-material/Work';
import { useAuth } from '../contexts/AuthContext';

const mockUserData = {
  displayName: 'John Doe',
  email: 'john.doe@example.com',
  bio: 'Passionate about learning and teaching. Software engineer by day, music enthusiast by night.',
  location: 'San Francisco, CA',
  occupation: 'Software Engineer',
  education: 'M.S. Computer Science',
  rating: 4.7,
  reviewCount: 28,
  skills: [
    {
      id: 1,
      skillName: 'Web Development',
      skillType: 'teaching',
      description: 'Full-stack web development with React, Node.js, and MongoDB.',
      tags: ['React', 'Node.js', 'MongoDB'],
      availability: {
        weekdays: ['Monday', 'Wednesday', 'Friday'],
        timeSlots: [{ startTime: '10:00 AM', endTime: '12:00 PM' }],
      },
    },
    {
      id: 2,
      skillName: 'Piano',
      skillType: 'learning',
      description: 'Looking to learn classical piano. Beginner level.',
      tags: ['Music', 'Classical', 'Piano'],
      availability: {
        weekdays: ['Tuesday', 'Thursday'],
        timeSlots: [{ startTime: '6:00 PM', endTime: '8:00 PM' }],
      },
    },
  ],
};

const Profile = () => {
  const theme = useTheme();
  const { currentUser } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [tabValue, setTabValue] = useState(0);
  const [userData, setUserData] = useState(mockUserData);

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  const handleEdit = () => {
    setIsEditing(true);
  };

  const handleSave = () => {
    setIsEditing(false);
    // TODO: Save changes to backend
  };

  const handleCancel = () => {
    setIsEditing(false);
    setUserData(mockUserData); // Reset to original data
  };

  const handleInputChange = (field) => (event) => {
    setUserData({ ...userData, [field]: event.target.value });
  };

  return (
    <Box sx={{ py: { xs: 2, md: 4 } }}>
      <Container maxWidth="lg">
        <Grid container spacing={4}>
          {/* Profile Overview */}
          <Grid item xs={12} md={4}>
            <Card sx={{ position: 'relative', mb: 3 }}>
              <Box
                sx={{
                  p: 3,
                  textAlign: 'center',
                  borderBottom: `1px solid ${theme.palette.divider}`,
                }}
              >
                <Box sx={{ position: 'relative', display: 'inline-block' }}>
                  <Avatar
                    src={currentUser?.photoURL}
                    sx={{
                      width: 120,
                      height: 120,
                      mx: 'auto',
                      border: `4px solid ${theme.palette.background.paper}`,
                      boxShadow: theme.shadows[3],
                    }}
                  >
                    {userData.displayName[0]}
                  </Avatar>
                  <IconButton
                    sx={{
                      position: 'absolute',
                      right: -8,
                      bottom: -8,
                      bgcolor: 'background.paper',
                      boxShadow: 1,
                      '&:hover': { bgcolor: 'grey.100' },
                    }}
                    size="small"
                  >
                    <PhotoCameraIcon fontSize="small" />
                  </IconButton>
                </Box>
                <Typography variant="h5" sx={{ mt: 2, mb: 1 }}>
                  {userData.displayName}
                </Typography>
                <Typography variant="body2" color="text.secondary" gutterBottom>
                  {userData.email}
                </Typography>
                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', mb: 2 }}>
                  <Rating value={userData.rating} precision={0.1} readOnly />
                  <Typography variant="body2" color="text.secondary" sx={{ ml: 1 }}>
                    ({userData.reviewCount} reviews)
                  </Typography>
                </Box>
              </Box>
              <CardContent>
                <Stack spacing={2}>
                  <Box>
                    <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                      Location
                    </Typography>
                    {isEditing ? (
                      <TextField
                        fullWidth
                        size="small"
                        value={userData.location}
                        onChange={handleInputChange('location')}
                      />
                    ) : (
                      <Typography variant="body1">{userData.location}</Typography>
                    )}
                  </Box>
                  <Box>
                    <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                      Occupation
                    </Typography>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <WorkIcon color="action" fontSize="small" />
                      {isEditing ? (
                        <TextField
                          fullWidth
                          size="small"
                          value={userData.occupation}
                          onChange={handleInputChange('occupation')}
                        />
                      ) : (
                        <Typography variant="body1">{userData.occupation}</Typography>
                      )}
                    </Box>
                  </Box>
                  <Box>
                    <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                      Education
                    </Typography>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <SchoolIcon color="action" fontSize="small" />
                      {isEditing ? (
                        <TextField
                          fullWidth
                          size="small"
                          value={userData.education}
                          onChange={handleInputChange('education')}
                        />
                      ) : (
                        <Typography variant="body1">{userData.education}</Typography>
                      )}
                    </Box>
                  </Box>
                </Stack>
              </CardContent>
              <Divider />
              <Box sx={{ p: 2 }}>
                {isEditing ? (
                  <Stack direction="row" spacing={1}>
                    <Button
                      fullWidth
                      variant="contained"
                      startIcon={<SaveIcon />}
                      onClick={handleSave}
                    >
                      Save
                    </Button>
                    <Button
                      fullWidth
                      variant="outlined"
                      startIcon={<CancelIcon />}
                      onClick={handleCancel}
                      color="error"
                    >
                      Cancel
                    </Button>
                  </Stack>
                ) : (
                  <Button
                    fullWidth
                    variant="outlined"
                    startIcon={<EditIcon />}
                    onClick={handleEdit}
                  >
                    Edit Profile
                  </Button>
                )}
              </Box>
            </Card>
          </Grid>

          {/* Main Content */}
          <Grid item xs={12} md={8}>
            <Card>
              <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
                <Tabs
                  value={tabValue}
                  onChange={handleTabChange}
                  sx={{
                    px: 2,
                    pt: 2,
                    '& .MuiTab-root': {
                      textTransform: 'none',
                      fontWeight: 600,
                    },
                  }}
                >
                  <Tab label="About" />
                  <Tab label="Skills" />
                  <Tab label="Reviews" />
                </Tabs>
              </Box>

              <CardContent>
                {tabValue === 0 && (
                  <Box>
                    <Typography variant="h6" gutterBottom>
                      Bio
                    </Typography>
                    {isEditing ? (
                      <TextField
                        fullWidth
                        multiline
                        rows={4}
                        value={userData.bio}
                        onChange={handleInputChange('bio')}
                        sx={{ mb: 3 }}
                      />
                    ) : (
                      <Typography variant="body1" paragraph>
                        {userData.bio}
                      </Typography>
                    )}
                  </Box>
                )}

                {tabValue === 1 && (
                  <Box>
                    <Box sx={{ mb: 3, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <Typography variant="h6">My Skills</Typography>
                      <Button
                        variant="contained"
                        onClick={() => {}}
                        sx={{ borderRadius: 2 }}
                      >
                        Add New Skill
                      </Button>
                    </Box>
                    <Grid container spacing={3}>
                      {userData.skills.map((skill) => (
                        <Grid item xs={12} key={skill.id}>
                          <Card sx={{ p: 2, display: 'flex', flexDirection: 'column' }}>
                            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                              <Typography variant="h6">{skill.skillName}</Typography>
                              <Chip label={skill.skillType} color={skill.skillType === 'teaching' ? 'primary' : 'secondary'} />
                            </Box>
                            <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                              {skill.description}
                            </Typography>
                            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                              {skill.tags.map((tag) => (
                                <Chip key={tag} label={tag} color="default" />
                              ))}
                            </Box>
                            <Box sx={{ mt: 2 }}>
                              <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                                Availability
                              </Typography>
                              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                                {skill.availability.weekdays.map((day) => (
                                  <Chip key={day} label={day} color="default" />
                                ))}
                              </Box>
                              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mt: 1 }}>
                                {skill.availability.timeSlots.map((slot) => (
                                  <Chip key={slot.startTime} label={`${slot.startTime} - ${slot.endTime}`} color="default" />
                                ))}
                              </Box>
                            </Box>
                          </Card>
                        </Grid>
                      ))}
                    </Grid>
                  </Box>
                )}

                {tabValue === 2 && (
                  <Box>
                    <Typography variant="h6" gutterBottom>
                      Reviews
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Coming soon...
                    </Typography>
                  </Box>
                )}
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      </Container>
    </Box>
  );
};

export default Profile;
