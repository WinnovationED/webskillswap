import React, { useState, useEffect } from 'react';
import {
  Container,
  Grid,
  Card,
  CardContent,
  Typography,
  Button,
  Avatar,
  Box,
  Chip,
  Tabs,
  Tab,
  CircularProgress,
  Alert,
} from '@mui/material';
import axios from 'axios';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';

function Requests() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [tab, setTab] = useState(0);

  useEffect(() => {
    fetchRequests();
  }, []);

  const fetchRequests = async () => {
    try {
      const response = await axios.get('http://localhost:5000/api/requests');
      setRequests(response.data);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching requests:', error);
      setError('Failed to load requests');
      setLoading(false);
    }
  };

  const handleRequestAction = async (requestId, status) => {
    try {
      await axios.patch(`http://localhost:5000/api/requests/${requestId}`, { status });
      setSuccess(`Request ${status} successfully`);
      fetchRequests();

      // If accepted, create a chat
      if (status === 'accepted') {
        const request = requests.find(r => r._id === requestId);
        const response = await axios.post('http://localhost:5000/api/chats', {
          userId: request.from._id,
          skillId: request.skill._id
        });
        navigate(`/chat/${response.data._id}`);
      }
    } catch (error) {
      console.error('Error updating request:', error);
      setError('Failed to update request');
    }
  };

  const filteredRequests = requests.filter(request => {
    if (tab === 0) return request.to._id === user._id && request.status === 'pending';
    if (tab === 1) return request.from._id === user._id;
    return request.to._id === user._id && request.status !== 'pending';
  });

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '80vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
      {success && <Alert severity="success" sx={{ mb: 2 }}>{success}</Alert>}

      <Tabs
        value={tab}
        onChange={(e, newValue) => setTab(newValue)}
        sx={{ mb: 3 }}
      >
        <Tab label="Received" />
        <Tab label="Sent" />
        <Tab label="History" />
      </Tabs>

      <Grid container spacing={3}>
        {filteredRequests.map((request) => (
          <Grid item xs={12} md={6} key={request._id}>
            <Card>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <Avatar
                    src={request.from.profileImage}
                    sx={{ width: 56, height: 56, mr: 2 }}
                  />
                  <Box>
                    <Typography variant="h6">
                      {request.from._id === user._id ? 'To: ' + request.to.name : 'From: ' + request.from.name}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Skill: {request.skill.skillName}
                    </Typography>
                  </Box>
                </Box>

                <Typography variant="body1" sx={{ mb: 2 }}>
                  {request.message}
                </Typography>

                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Chip
                    label={request.status.charAt(0).toUpperCase() + request.status.slice(1)}
                    color={
                      request.status === 'accepted' ? 'success' :
                      request.status === 'rejected' ? 'error' :
                      'default'
                    }
                  />
                  
                  {request.to._id === user._id && request.status === 'pending' && (
                    <Box sx={{ display: 'flex', gap: 1 }}>
                      <Button
                        variant="contained"
                        color="success"
                        onClick={() => handleRequestAction(request._id, 'accepted')}
                      >
                        Accept
                      </Button>
                      <Button
                        variant="outlined"
                        color="error"
                        onClick={() => handleRequestAction(request._id, 'rejected')}
                      >
                        Decline
                      </Button>
                    </Box>
                  )}
                </Box>
              </CardContent>
            </Card>
          </Grid>
        ))}

        {filteredRequests.length === 0 && (
          <Grid item xs={12}>
            <Box
              sx={{
                textAlign: 'center',
                py: 8,
                bgcolor: 'background.paper',
                borderRadius: 2,
              }}
            >
              <Typography variant="h6" color="text.secondary">
                No requests found
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                {tab === 0 ? "You don't have any pending requests" :
                 tab === 1 ? "You haven't sent any requests yet" :
                 "No request history available"}
              </Typography>
            </Box>
          </Grid>
        )}
      </Grid>
    </Container>
  );
}

export default Requests;
