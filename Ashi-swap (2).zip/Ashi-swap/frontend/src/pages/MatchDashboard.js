import React from 'react';
import { Container, Typography, Box } from '@mui/material';
import MatchManager from '../components/MatchManager';

function MatchDashboard() {
  return (
    <Container maxWidth="lg" sx={{ py: 4 }}>
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Skill Match Dashboard
        </Typography>
        <Typography variant="body1" color="text.secondary">
          Find and connect with users who can teach you the skills you want to learn.
        </Typography>
      </Box>
      <MatchManager />
    </Container>
  );
}

export default MatchDashboard;
