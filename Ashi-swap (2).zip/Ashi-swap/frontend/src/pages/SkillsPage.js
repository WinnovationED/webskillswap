import React, { useState, useEffect } from 'react';
import {
  Container,
  Grid,
  Card,
  CardContent,
  Typography,
  Button,
  Box,
  Chip,
  IconButton,
  Rating,
  Divider,
  CircularProgress,
  Alert,
} from '@mui/material';
import { Add as AddIcon, Edit as EditIcon } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

function SkillsPage() {
  const [teachingSkills, setTeachingSkills] = useState([]);
  const [learningSkills, setLearningSkills] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const { currentUser, token } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    fetchSkills();
  }, []);

  const fetchSkills = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/user-skills', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (!response.ok) {
        throw new Error('Failed to fetch skills');
      }

      const data = await response.json();
      setTeachingSkills(data.teachingSkills || []);
      setLearningSkills(data.learningSkills || []);
      setError('');
    } catch (err) {
      setError('Failed to load skills. Please try again later.');
      console.error('Error fetching skills:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="80vh">
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Container maxWidth="lg" sx={{ py: 4 }}>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={4}>
        <Typography variant="h4" component="h1" gutterBottom>
          My Skills
        </Typography>
        <Button
          variant="contained"
          color="primary"
          startIcon={<AddIcon />}
          onClick={() => navigate('/skills/add')}
        >
          Add Skill
        </Button>
      </Box>

      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}

      <Grid container spacing={4}>
        {/* Teaching Skills */}
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h5" gutterBottom>
                Skills I Can Teach
              </Typography>
              <Divider sx={{ mb: 2 }} />
              {teachingSkills.length === 0 ? (
                <Typography color="text.secondary">
                  No teaching skills added yet.
                </Typography>
              ) : (
                <Grid container spacing={2}>
                  {teachingSkills.map((skill) => (
                    <Grid item xs={12} key={skill._id}>
                      <Card variant="outlined">
                        <CardContent>
                          <Box display="flex" justifyContent="space-between" alignItems="center">
                            <Typography variant="h6">{skill.skill.name}</Typography>
                            <IconButton
                              size="small"
                              onClick={() => navigate(`/skills/edit/${skill._id}`)}
                            >
                              <EditIcon />
                            </IconButton>
                          </Box>
                          <Rating value={skill.proficiency} readOnly />
                          <Typography variant="body2" color="text.secondary" paragraph>
                            {skill.description}
                          </Typography>
                          <Box display="flex" gap={1} flexWrap="wrap">
                            {skill.skill.tags?.map((tag) => (
                              <Chip key={tag} label={tag} size="small" />
                            ))}
                          </Box>
                        </CardContent>
                      </Card>
                    </Grid>
                  ))}
                </Grid>
              )}
            </CardContent>
          </Card>
        </Grid>

        {/* Learning Skills */}
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h5" gutterBottom>
                Skills I Want to Learn
              </Typography>
              <Divider sx={{ mb: 2 }} />
              {learningSkills.length === 0 ? (
                <Typography color="text.secondary">
                  No learning skills added yet.
                </Typography>
              ) : (
                <Grid container spacing={2}>
                  {learningSkills.map((skill) => (
                    <Grid item xs={12} key={skill._id}>
                      <Card variant="outlined">
                        <CardContent>
                          <Box display="flex" justifyContent="space-between" alignItems="center">
                            <Typography variant="h6">{skill.skill.name}</Typography>
                            <IconButton
                              size="small"
                              onClick={() => navigate(`/skills/edit/${skill._id}`)}
                            >
                              <EditIcon />
                            </IconButton>
                          </Box>
                          <Box display="flex" alignItems="center" gap={2} mb={1}>
                            <Box>
                              <Typography variant="body2" color="text.secondary">
                                Current Level
                              </Typography>
                              <Rating value={skill.currentLevel} readOnly />
                            </Box>
                            <Box>
                              <Typography variant="body2" color="text.secondary">
                                Target Level
                              </Typography>
                              <Rating value={skill.targetLevel} readOnly />
                            </Box>
                          </Box>
                          <Box display="flex" gap={1} flexWrap="wrap">
                            {skill.skill.tags?.map((tag) => (
                              <Chip key={tag} label={tag} size="small" />
                            ))}
                          </Box>
                        </CardContent>
                      </Card>
                    </Grid>
                  ))}
                </Grid>
              )}
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Container>
  );
}

export default SkillsPage;
