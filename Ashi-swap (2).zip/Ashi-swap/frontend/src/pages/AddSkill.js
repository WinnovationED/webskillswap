import React, { useState } from 'react';
import {
  Container,
  Paper,
  Typography,
  TextField,
  Button,
  Box,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Rating,
  FormHelperText,
  Alert,
  CircularProgress,
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

function AddSkill() {
  const [formData, setFormData] = useState({
    skillName: '',
    skillType: '', // 'teaching' or 'learning'
    proficiency: 3,
    currentLevel: 1,
    targetLevel: 3,
    description: '',
    tags: '',
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const { token } = useAuth();
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      // First, create or get the skill
      const skillResponse = await fetch('http://localhost:5000/api/skills', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          name: formData.skillName,
          tags: formData.tags.split(',').map(tag => tag.trim()).filter(tag => tag),
        }),
      });

      if (!skillResponse.ok) {
        throw new Error('Failed to create skill');
      }

      const skillData = await skillResponse.json();

      // Then, associate it with the user
      const userSkillResponse = await fetch('http://localhost:5000/api/user-skills', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          skillId: skillData.skill._id,
          type: formData.skillType,
          ...(formData.skillType === 'teaching' ? {
            proficiency: formData.proficiency,
            description: formData.description,
          } : {
            currentLevel: formData.currentLevel,
            targetLevel: formData.targetLevel,
          }),
        }),
      });

      if (!userSkillResponse.ok) {
        throw new Error('Failed to add skill to profile');
      }

      navigate('/skills');
    } catch (err) {
      setError(err.message || 'Failed to add skill. Please try again.');
      console.error('Error adding skill:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Container maxWidth="md" sx={{ py: 4 }}>
      <Paper sx={{ p: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Add New Skill
        </Typography>

        {error && (
          <Alert severity="error" sx={{ mb: 3 }}>
            {error}
          </Alert>
        )}

        <Box component="form" onSubmit={handleSubmit}>
          <TextField
            fullWidth
            label="Skill Name"
            name="skillName"
            value={formData.skillName}
            onChange={handleChange}
            required
            margin="normal"
          />

          <FormControl fullWidth margin="normal" required>
            <InputLabel>Skill Type</InputLabel>
            <Select
              name="skillType"
              value={formData.skillType}
              onChange={handleChange}
              label="Skill Type"
            >
              <MenuItem value="teaching">I can teach this</MenuItem>
              <MenuItem value="learning">I want to learn this</MenuItem>
            </Select>
          </FormControl>

          {formData.skillType === 'teaching' ? (
            <>
              <Box sx={{ mt: 2 }}>
                <Typography component="legend">Proficiency Level</Typography>
                <Rating
                  name="proficiency"
                  value={formData.proficiency}
                  onChange={(event, newValue) => {
                    setFormData(prev => ({ ...prev, proficiency: newValue }));
                  }}
                />
              </Box>

              <TextField
                fullWidth
                label="Description"
                name="description"
                value={formData.description}
                onChange={handleChange}
                multiline
                rows={4}
                margin="normal"
                helperText="Describe your experience and what you can teach"
              />
            </>
          ) : formData.skillType === 'learning' ? (
            <Box sx={{ mt: 2 }}>
              <Typography component="legend">Current Level</Typography>
              <Rating
                name="currentLevel"
                value={formData.currentLevel}
                onChange={(event, newValue) => {
                  setFormData(prev => ({ ...prev, currentLevel: newValue }));
                }}
              />

              <Typography component="legend" sx={{ mt: 2 }}>
                Target Level
              </Typography>
              <Rating
                name="targetLevel"
                value={formData.targetLevel}
                onChange={(event, newValue) => {
                  setFormData(prev => ({ ...prev, targetLevel: newValue }));
                }}
              />
            </Box>
          ) : null}

          <TextField
            fullWidth
            label="Tags"
            name="tags"
            value={formData.tags}
            onChange={handleChange}
            margin="normal"
            helperText="Enter tags separated by commas (e.g., programming, web development, javascript)"
          />

          <Box sx={{ mt: 3, display: 'flex', gap: 2 }}>
            <Button
              type="submit"
              variant="contained"
              color="primary"
              disabled={loading}
            >
              {loading ? <CircularProgress size={24} /> : 'Add Skill'}
            </Button>
            <Button
              variant="outlined"
              onClick={() => navigate('/skills')}
              disabled={loading}
            >
              Cancel
            </Button>
          </Box>
        </Box>
      </Paper>
    </Container>
  );
}

export default AddSkill;
