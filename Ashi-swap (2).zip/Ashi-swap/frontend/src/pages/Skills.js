import React, { useState, useEffect } from 'react';
import {
  Container,
  Grid,
  Typography,
  Box,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  CircularProgress,
  Card,
  CardContent,
  CardActions,
  Chip,
  IconButton,
  TextField,
  InputAdornment,
  Menu,
  MenuItem,
  Tab,
  Tabs,
  Rating,
  Tooltip,
  ListItemIcon,
  ListItemText,
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import { useAuth } from '../contexts/AuthContext';
import AddSkillForm from '../components/AddSkillForm';

const popularSkills = [
  'Programming',
  'Music',
  'Language',
  'Cooking',
  'Photography',
  'Art',
  'Mathematics',
  'Writing',
  'Design',
  'Business',
];

function Skills() {
  const { currentUser } = useAuth();
  const [skills, setSkills] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [addSkillOpen, setAddSkillOpen] = useState(false);
  const [selectedSkill, setSelectedSkill] = useState(null);
  const [editMode, setEditMode] = useState(false);
  const [anchorEl, setAnchorEl] = useState(null);
  const [selectedTab, setSelectedTab] = useState('all');
  const [detailsDialogOpen, setDetailsDialogOpen] = useState(false);
  const [filters, setFilters] = useState({
    type: 'all',
    rating: 0,
    tags: [],
  });
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);

  useEffect(() => {
    fetchSkills();
  }, []);

  const fetchSkills = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/skills');
      if (!response.ok) {
        throw new Error('Failed to fetch skills');
      }
      const data = await response.json();
      setSkills(Array.isArray(data) ? data : data.skills || []);
      setError('');
    } catch (error) {
      console.error('Error fetching skills:', error);
      setError('Failed to load skills. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  const handleAddSkill = async (skillData) => {
    if (!currentUser) {
      setError('Please login to add a skill');
      return;
    }

    try {
      const response = await fetch('http://localhost:5000/api/skills', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
        },
        body: JSON.stringify({
          skillName: skillData.skillName,
          description: skillData.description,
          skillType: skillData.skillType,
          tags: skillData.tags,
          availability: skillData.availability,
        }),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Failed to add skill');
      }

      await fetchSkills();
      setAddSkillOpen(false);
      setError('');
    } catch (error) {
      console.error('Error adding skill:', error);
      throw new Error('Failed to add skill. Please try again.');
    }
  };

  const handleEditSkill = async (skillData) => {
    if (!currentUser || !selectedSkill) return;

    try {
      const response = await fetch(`http://localhost:5000/api/skills/${selectedSkill._id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
        },
        body: JSON.stringify(skillData),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Failed to update skill');
      }

      await fetchSkills();
      setSelectedSkill(null);
      setEditMode(false);
      setError('');
    } catch (error) {
      console.error('Error updating skill:', error);
      setError('Failed to update skill. Please try again.');
    }
  };

  const handleDeleteSkill = async (skillId) => {
    if (!currentUser) return;

    try {
      const response = await fetch(`http://localhost:5000/api/skills/${skillId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
        },
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Failed to delete skill');
      }

      await fetchSkills();
      setSelectedSkill(null);
      setAnchorEl(null);
      setError('');
    } catch (error) {
      console.error('Error deleting skill:', error);
      setError('Failed to delete skill. Please try again.');
    }
  };

  const handleRateSkill = async (skillId, rating) => {
    if (!currentUser) {
      setError('Please login to rate skills');
      return;
    }

    try {
      const response = await fetch(`http://localhost:5000/api/skills/${skillId}/rate`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
        },
        body: JSON.stringify({ rating }),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Failed to rate skill');
      }

      await fetchSkills();
      setError('');
    } catch (error) {
      console.error('Error rating skill:', error);
      setError('Failed to rate skill. Please try again.');
    }
  };

  const handleMenuOpen = (event, skill) => {
    setSelectedSkill(skill);
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const handleTabChange = (event, newValue) => {
    setSelectedTab(newValue);
  };

  const handleSkillClick = (skill) => {
    setSelectedSkill(skill);
    setDetailsDialogOpen(true);
  };

  const filteredSkills = skills.filter(skill => {
    if (!skill || typeof skill.skillName !== 'string') return false;

    const matchesSearch = searchQuery.toLowerCase().trim() === '' ||
      skill.skillName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (Array.isArray(skill.tags) && skill.tags.some(tag => 
        typeof tag === 'string' && tag.toLowerCase().includes(searchQuery.toLowerCase())
      ));

    const matchesType = filters.type === 'all' || skill.skillType === filters.type;
    const matchesRating = skill.averageRating >= filters.rating;
    const matchesTabs = selectedTab === 'all' || 
      (selectedTab === 'teaching' && skill.skillType === 'teaching') ||
      (selectedTab === 'learning' && skill.skillType === 'learning');

    return matchesSearch && matchesType && matchesRating && matchesTabs;
  });

  const handleEdit = () => {
    handleMenuClose();
    setEditMode(true);
  };

  const handleDelete = () => {
    handleMenuClose();
    setDeleteDialogOpen(true);
  };

  const confirmDelete = () => {
    handleDeleteSkill(selectedSkill._id);
    setDeleteDialogOpen(false);
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '80vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
        <Typography variant="h4">
          Skills Exchange
        </Typography>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={() => setAddSkillOpen(true)}
        >
          Add Skill
        </Button>
      </Box>

      {error && (
        <Box sx={{ mb: 2 }}>
          <Typography color="error">{error}</Typography>
        </Box>
      )}

      {/* Tabs */}
      <Tabs
        value={selectedTab}
        onChange={handleTabChange}
        sx={{ mb: 3 }}
        centered
      >
        <Tab value="all" label="All Skills" />
        <Tab value="teaching" label="Teaching" />
        <Tab value="learning" label="Learning" />
      </Tabs>

      {/* Search and Filters */}
      <Box sx={{ mb: 4 }}>
        <TextField
          fullWidth
          placeholder="Search skills or tags..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          sx={{ mb: 2 }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon />
              </InputAdornment>
            ),
          }}
        />

        <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
          {popularSkills.map((skill) => (
            <Chip
              key={skill}
              label={skill}
              onClick={() => setSearchQuery(skill)}
              clickable
            />
          ))}
        </Box>
      </Box>

      {/* Skills Grid */}
      <Grid container spacing={3}>
        {filteredSkills.map((skill) => (
          <Grid item xs={12} sm={6} md={4} key={skill._id}>
            <Card
              sx={{
                height: '100%',
                display: 'flex',
                flexDirection: 'column',
                position: 'relative',
              }}
            >
              <CardContent>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <Typography variant="h6" gutterBottom>
                    {skill.skillName}
                  </Typography>
                  {currentUser && skill.createdBy === currentUser._id && (
                    <IconButton
                      size="small"
                      onClick={(e) => handleMenuOpen(e, skill)}
                      aria-label="skill options"
                    >
                      <MoreVertIcon />
                    </IconButton>
                  )}
                </Box>
                <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                  {skill.description}
                </Typography>
                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5, mb: 2 }}>
                  {Array.isArray(skill.tags) && skill.tags.map((tag) => (
                    <Chip key={tag} label={tag} size="small" />
                  ))}
                </Box>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <Rating
                    value={skill.averageRating || 0}
                    precision={0.5}
                    onChange={(event, newValue) => handleRateSkill(skill._id, newValue)}
                    readOnly={!currentUser || skill.createdBy === currentUser._id}
                    aria-label="rate skill"
                  />
                  <Typography variant="body2" color="text.secondary">
                    ({skill.ratings?.length || 0})
                  </Typography>
                </Box>
              </CardContent>
              <CardActions sx={{ mt: 'auto' }}>
                <Chip
                  label={skill.skillType === 'teaching' ? 'Teaching' : 'Learning'}
                  color={skill.skillType === 'teaching' ? 'primary' : 'secondary'}
                  size="small"
                />
                <Box sx={{ flexGrow: 1 }} />
                <Button 
                  size="small" 
                  onClick={() => handleSkillClick(skill)}
                  aria-label={`Learn more about ${skill.skillName}`}
                >
                  Learn More
                </Button>
              </CardActions>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* Add/Edit Skill Form */}
      <AddSkillForm
        open={addSkillOpen || editMode}
        onClose={() => {
          setAddSkillOpen(false);
          setEditMode(false);
          setSelectedSkill(null);
        }}
        onSubmit={editMode ? handleEditSkill : handleAddSkill}
        initialData={editMode ? selectedSkill : null}
      />

      {/* Skill Details Dialog */}
      <Dialog
        open={detailsDialogOpen}
        onClose={() => setDetailsDialogOpen(false)}
        maxWidth="md"
        fullWidth
        aria-labelledby="skill-details-title"
        disableEscapeKeyDown={false}
        keepMounted={false}
      >
        {selectedSkill && (
          <>
            <DialogTitle id="skill-details-title">
              {selectedSkill.skillName}
            </DialogTitle>
            <DialogContent>
              <Typography variant="body1" paragraph>
                {selectedSkill.description}
              </Typography>
              <Typography variant="subtitle1" gutterBottom>
                Tags:
              </Typography>
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5, mb: 2 }}>
                {Array.isArray(selectedSkill.tags) && selectedSkill.tags.map((tag) => (
                  <Chip key={tag} label={tag} size="small" />
                ))}
              </Box>
              <Typography variant="subtitle1" gutterBottom>
                Availability:
              </Typography>
              <Box sx={{ mb: 2 }}>
                <Typography variant="body2">
                  Days: {selectedSkill.availability.weekdays.join(', ')}
                </Typography>
                <Typography variant="body2">
                  Time: {selectedSkill.availability.timeSlots[0].startTime} - {selectedSkill.availability.timeSlots[0].endTime}
                </Typography>
              </Box>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <Rating
                  value={selectedSkill.averageRating || 0}
                  precision={0.5}
                  onChange={(event, newValue) => handleRateSkill(selectedSkill._id, newValue)}
                  readOnly={!currentUser || selectedSkill.createdBy === currentUser._id}
                  aria-label="rate skill in details"
                />
                <Typography variant="body2" color="text.secondary">
                  ({selectedSkill.ratings?.length || 0} ratings)
                </Typography>
              </Box>
            </DialogContent>
            <DialogActions>
              <Button 
                onClick={() => setDetailsDialogOpen(false)}
                aria-label="close dialog"
              >
                Close
              </Button>
            </DialogActions>
          </>
        )}
      </Dialog>

      {/* Skill Options Menu */}
      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={handleMenuClose}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'right',
        }}
        transformOrigin={{
          vertical: 'top',
          horizontal: 'right',
        }}
      >
        <MenuItem onClick={handleEdit}>
          <ListItemIcon>
            <EditIcon fontSize="small" />
          </ListItemIcon>
          <ListItemText>Edit</ListItemText>
        </MenuItem>
        <MenuItem onClick={handleDelete}>
          <ListItemIcon>
            <DeleteIcon fontSize="small" />
          </ListItemIcon>
          <ListItemText>Delete</ListItemText>
        </MenuItem>
      </Menu>

      {/* Delete Confirmation Dialog */}
      <Dialog
        open={deleteDialogOpen}
        onClose={() => setDeleteDialogOpen(false)}
        aria-labelledby="delete-dialog-title"
        disableEscapeKeyDown={false}
        keepMounted={false}
      >
        <DialogTitle id="delete-dialog-title">Delete Skill</DialogTitle>
        <DialogContent>
          <Typography>
            Are you sure you want to delete this skill? This action cannot be undone.
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteDialogOpen(false)}>Cancel</Button>
          <Button onClick={confirmDelete} color="error">
            Delete
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
}

export default Skills;
