import React, { useState, useEffect } from 'react';
import {
  Box,
  Container,
  Typography,
  Grid,
  Card,
  CardContent,
  Chip,
  Button,
  TextField,
  InputAdornment,
  useTheme,
  useMediaQuery,
  Tabs,
  Tab,
  CircularProgress,
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import FilterListIcon from '@mui/icons-material/FilterList';
import TrendingUpIcon from '@mui/icons-material/TrendingUp';
import SkillCard from '../components/SkillCard';
import { useAuth } from '../contexts/AuthContext';

const mockSkills = [
  {
    id: 1,
    skillName: 'Web Development',
    skillType: 'teaching',
    description: 'Full-stack web development with React, Node.js, and MongoDB. Learn modern web technologies and best practices.',
    tags: ['React', 'Node.js', 'MongoDB'],
    availability: {
      weekdays: ['Monday', 'Wednesday', 'Friday'],
      timeSlots: [{ startTime: '10:00 AM', endTime: '12:00 PM' }],
    },
    createdBy: {
      name: 'John Doe',
      rating: 4.5,
      profileImage: 'https://api.dicebear.com/7.x/avataaars/svg?seed=John',
    },
  },
  {
    id: 2,
    skillName: 'Digital Marketing',
    skillType: 'learning',
    description: 'Looking to learn social media marketing, SEO, and content strategy. Willing to exchange with graphic design skills.',
    tags: ['Social Media', 'SEO', 'Content Marketing'],
    availability: {
      weekdays: ['Tuesday', 'Thursday'],
      timeSlots: [{ startTime: '2:00 PM', endTime: '4:00 PM' }],
    },
    createdBy: {
      name: 'Sarah Smith',
      rating: 4.8,
      profileImage: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah',
    },
  },
  {
    id: 3,
    skillName: 'UI/UX Design',
    skillType: 'teaching',
    description: 'Professional UI/UX designer offering lessons in user interface design, prototyping, and design thinking.',
    tags: ['Figma', 'Adobe XD', 'Design Systems'],
    availability: {
      weekdays: ['Monday', 'Wednesday'],
      timeSlots: [{ startTime: '3:00 PM', endTime: '5:00 PM' }],
    },
    createdBy: {
      name: 'Mike Johnson',
      rating: 4.9,
      profileImage: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Mike',
    },
  },
];

const Home = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const [tabValue, setTabValue] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');
  const [skills, setSkills] = useState([]);
  const [loading, setLoading] = useState(true);
  const { currentUser } = useAuth();

  useEffect(() => {
    // Simulating API call
    const fetchSkills = async () => {
      try {
        // Replace with actual API call
        setTimeout(() => {
          setSkills(mockSkills);
          setLoading(false);
        }, 1000);
      } catch (error) {
        console.error('Error fetching skills:', error);
        setLoading(false);
      }
    };

    fetchSkills();
  }, []);

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  const filteredSkills = skills.filter((skill) => {
    const matchesSearch = skill.skillName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      skill.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      skill.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesTab = tabValue === 0 ||
      (tabValue === 1 && skill.skillType === 'teaching') ||
      (tabValue === 2 && skill.skillType === 'learning');

    return matchesSearch && matchesTab;
  });

  return (
    <Box sx={{ py: { xs: 2, md: 4 } }}>
      <Container maxWidth="lg">
        {/* Welcome Section */}
        <Box sx={{ mb: 4 }}>
          <Typography variant="h4" gutterBottom>
            Welcome back, {currentUser?.displayName || 'Learner'}! 👋
          </Typography>
          <Typography variant="body1" color="text.secondary">
            Discover new skills to learn or share your expertise with others.
          </Typography>
        </Box>

        {/* Search and Filter Section */}
        <Box sx={{ mb: 4 }}>
          <Grid container spacing={2} alignItems="center">
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                variant="outlined"
                placeholder="Search skills, topics, or tags..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <SearchIcon color="action" />
                    </InputAdornment>
                  ),
                }}
                sx={{
                  bgcolor: 'background.paper',
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderColor: 'transparent',
                    },
                    '&:hover fieldset': {
                      borderColor: 'divider',
                    },
                    '&.Mui-focused fieldset': {
                      borderColor: 'primary.main',
                    },
                  },
                }}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Box sx={{ display: 'flex', gap: 2, justifyContent: { xs: 'flex-start', md: 'flex-end' } }}>
                <Button
                  variant="outlined"
                  startIcon={<FilterListIcon />}
                  sx={{ borderRadius: 2 }}
                >
                  Filters
                </Button>
                <Button
                  variant="outlined"
                  startIcon={<TrendingUpIcon />}
                  sx={{ borderRadius: 2 }}
                >
                  Sort By
                </Button>
              </Box>
            </Grid>
          </Grid>
        </Box>

        {/* Tabs Section */}
        <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 4 }}>
          <Tabs
            value={tabValue}
            onChange={handleTabChange}
            variant={isMobile ? 'fullWidth' : 'standard'}
            sx={{
              '& .MuiTab-root': {
                textTransform: 'none',
                fontWeight: 600,
                fontSize: '1rem',
              },
            }}
          >
            <Tab label="All Skills" />
            <Tab label="Teaching" />
            <Tab label="Learning" />
          </Tabs>
        </Box>

        {/* Skills Grid */}
        {loading ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', py: 8 }}>
            <CircularProgress />
          </Box>
        ) : filteredSkills.length > 0 ? (
          <Grid container spacing={3}>
            {filteredSkills.map((skill) => (
              <Grid item xs={12} sm={6} md={4} key={skill.id}>
                <SkillCard
                  skill={skill}
                  onMatch={(skill) => console.log('Match requested:', skill)}
                  showMatchButton
                />
              </Grid>
            ))}
          </Grid>
        ) : (
          <Box
            sx={{
              py: 8,
              textAlign: 'center',
              bgcolor: 'background.paper',
              borderRadius: 2,
            }}
          >
            <Typography variant="h6" gutterBottom>
              No skills found
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Try adjusting your search or filters
            </Typography>
          </Box>
        )}
      </Container>
    </Box>
  );
};

export default Home;
