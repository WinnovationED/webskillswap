import React, { useState, useEffect } from 'react';
import {
  Container,
  Paper,
  Typography,
  TextField,
  Button,
  Box,
  Rating,
  Alert,
  CircularProgress,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
} from '@mui/material';
import { useNavigate, useParams } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

function EditSkill() {
  const [formData, setFormData] = useState({
    skillName: '',
    proficiency: 3,
    currentLevel: 1,
    targetLevel: 3,
    description: '',
    tags: '',
    type: '',
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [deleteDialog, setDeleteDialog] = useState(false);
  const { token } = useAuth();
  const navigate = useNavigate();
  const { skillId } = useParams();

  useEffect(() => {
    fetchSkillDetails();
  }, [skillId]);

  const fetchSkillDetails = async () => {
    try {
      const response = await fetch(`http://localhost:5000/api/user-skills/${skillId}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (!response.ok) {
        throw new Error('Failed to fetch skill details');
      }

      const data = await response.json();
      setFormData({
        skillName: data.skill.name,
        tags: data.skill.tags.join(', '),
        type: data.type,
        ...(data.type === 'teaching' ? {
          proficiency: data.proficiency,
          description: data.description,
        } : {
          currentLevel: data.currentLevel,
          targetLevel: data.targetLevel,
        }),
      });
      setError('');
    } catch (err) {
      setError('Failed to load skill details. Please try again.');
      console.error('Error fetching skill details:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    setError('');

    try {
      const response = await fetch(`http://localhost:5000/api/user-skills/${skillId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          ...(formData.type === 'teaching' ? {
            proficiency: formData.proficiency,
            description: formData.description,
          } : {
            currentLevel: formData.currentLevel,
            targetLevel: formData.targetLevel,
          }),
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to update skill');
      }

      navigate('/skills');
    } catch (err) {
      setError(err.message || 'Failed to update skill. Please try again.');
      console.error('Error updating skill:', err);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    setDeleteDialog(false);
    setSaving(true);
    setError('');

    try {
      const response = await fetch(`http://localhost:5000/api/user-skills/${skillId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (!response.ok) {
        throw new Error('Failed to delete skill');
      }

      navigate('/skills');
    } catch (err) {
      setError(err.message || 'Failed to delete skill. Please try again.');
      console.error('Error deleting skill:', err);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="80vh">
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Container maxWidth="md" sx={{ py: 4 }}>
      <Paper sx={{ p: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Edit Skill
        </Typography>

        {error && (
          <Alert severity="error" sx={{ mb: 3 }}>
            {error}
          </Alert>
        )}

        <Box component="form" onSubmit={handleSubmit}>
          <TextField
            fullWidth
            label="Skill Name"
            value={formData.skillName}
            disabled
            margin="normal"
          />

          {formData.type === 'teaching' ? (
            <>
              <Box sx={{ mt: 2 }}>
                <Typography component="legend">Proficiency Level</Typography>
                <Rating
                  name="proficiency"
                  value={formData.proficiency}
                  onChange={(event, newValue) => {
                    setFormData(prev => ({ ...prev, proficiency: newValue }));
                  }}
                />
              </Box>

              <TextField
                fullWidth
                label="Description"
                name="description"
                value={formData.description}
                onChange={handleChange}
                multiline
                rows={4}
                margin="normal"
                helperText="Describe your experience and what you can teach"
              />
            </>
          ) : (
            <Box sx={{ mt: 2 }}>
              <Typography component="legend">Current Level</Typography>
              <Rating
                name="currentLevel"
                value={formData.currentLevel}
                onChange={(event, newValue) => {
                  setFormData(prev => ({ ...prev, currentLevel: newValue }));
                }}
              />

              <Typography component="legend" sx={{ mt: 2 }}>
                Target Level
              </Typography>
              <Rating
                name="targetLevel"
                value={formData.targetLevel}
                onChange={(event, newValue) => {
                  setFormData(prev => ({ ...prev, targetLevel: newValue }));
                }}
              />
            </Box>
          )}

          <TextField
            fullWidth
            label="Tags"
            value={formData.tags}
            disabled
            margin="normal"
          />

          <Box sx={{ mt: 3, display: 'flex', gap: 2 }}>
            <Button
              type="submit"
              variant="contained"
              color="primary"
              disabled={saving}
            >
              {saving ? <CircularProgress size={24} /> : 'Save Changes'}
            </Button>
            <Button
              variant="outlined"
              color="error"
              onClick={() => setDeleteDialog(true)}
              disabled={saving}
            >
              Delete Skill
            </Button>
            <Button
              variant="outlined"
              onClick={() => navigate('/skills')}
              disabled={saving}
            >
              Cancel
            </Button>
          </Box>
        </Box>
      </Paper>

      <Dialog
        open={deleteDialog}
        onClose={() => setDeleteDialog(false)}
      >
        <DialogTitle>Delete Skill</DialogTitle>
        <DialogContent>
          Are you sure you want to delete this skill? This action cannot be undone.
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteDialog(false)}>Cancel</Button>
          <Button onClick={handleDelete} color="error" autoFocus>
            Delete
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
}

export default EditSkill;
