import React, { useState, useEffect } from 'react';
import {
  Container,
  Grid,
  Card,
  CardContent,
  Typography,
  Box,
  Tabs,
  Tab,
  Chip,
  Button,
  TextField,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  IconButton,
  Badge,
  Alert,
  Avatar
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useNotification } from '../contexts/NotificationContext';
import { Search as SearchIcon, FilterList as FilterIcon } from '@mui/icons-material';

function TabPanel({ children, value, index }) {
  return (
    <div role="tabpanel" hidden={value !== index}>
      {value === index && <Box sx={{ py: 3 }}>{children}</Box>}
    </div>
  );
}

export default function RequestDashboard() {
  const [value, setValue] = useState(0);
  const [requests, setRequests] = useState([]);
  const [filteredRequests, setFilteredRequests] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState({
    status: '',
    type: '',
    skill: ''
  });
  const [filterDialogOpen, setFilterDialogOpen] = useState(false);
  const [scheduleDialogOpen, setScheduleDialogOpen] = useState(false);
  const [selectedRequest, setSelectedRequest] = useState(null);
  const [schedule, setSchedule] = useState({
    startDate: '',
    endDate: '',
    timeSlots: []
  });

  const { currentUser } = useAuth();
  const { addNotification } = useNotification();
  const navigate = useNavigate();

  useEffect(() => {
    fetchRequests();
  }, [currentUser]);

  useEffect(() => {
    applyFilters();
  }, [requests, searchQuery, filters]);

  const fetchRequests = async () => {
    try {
      const response = await fetch('/api/requests', {
        headers: {
          'Authorization': `Bearer ${currentUser.token}`
        }
      });
      const data = await response.json();
      if (response.ok) {
        setRequests(data);
      }
    } catch (error) {
      console.error('Error fetching requests:', error);
    }
  };

  const applyFilters = () => {
    let filtered = [...requests];

    // Apply status filter
    if (filters.status) {
      filtered = filtered.filter(request => request.status === filters.status);
    }

    // Apply type filter
    if (filters.type) {
      filtered = filtered.filter(request => request.type === filters.type);
    }

    // Apply skill filter
    if (filters.skill) {
      filtered = filtered.filter(request => 
        request.skill.name.toLowerCase().includes(filters.skill.toLowerCase())
      );
    }

    // Apply search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(request =>
        request.skill.name.toLowerCase().includes(query) ||
        request.message.toLowerCase().includes(query) ||
        request.teacher.name.toLowerCase().includes(query)
      );
    }

    setFilteredRequests(filtered);
  };

  const handleTabChange = (event, newValue) => {
    setValue(newValue);
  };

  const handleFilterChange = (field, value) => {
    setFilters(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleRequestResponse = async (requestId, status) => {
    try {
      const response = await fetch(`/api/requests/${requestId}/status`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${currentUser.token}`
        },
        body: JSON.stringify({ status })
      });

      if (response.ok) {
        fetchRequests();
        addNotification({
          type: `request_${status}`,
          message: `Request ${status} successfully`
        });
      }
    } catch (error) {
      console.error('Error updating request status:', error);
    }
  };

  const handleScheduleSubmit = async () => {
    try {
      const response = await fetch(`/api/requests/${selectedRequest._id}/schedule`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${currentUser.token}`
        },
        body: JSON.stringify(schedule)
      });

      if (response.ok) {
        setScheduleDialogOpen(false);
        fetchRequests();
        addNotification({
          type: 'schedule_updated',
          message: 'Learning session scheduled successfully'
        });
      }
    } catch (error) {
      console.error('Error updating schedule:', error);
    }
  };

  const openChat = (request) => {
    navigate(`/chat/${request.chatRoom}`);
  };

  const renderRequestCard = (request) => (
    <Grid item xs={12} md={6} key={request._id}>
      <Card>
        <CardContent>
          <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
            <Avatar
              src={request.teacher?.profileImage}
              alt={request.teacher?.name}
              sx={{ width: 56, height: 56, mr: 2 }}
            />
            <Box>
              <Typography variant="h6">
                {request.teacher?.name}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Teaching {request.skill?.name}
              </Typography>
            </Box>
          </Box>

          <Box sx={{ mb: 2 }}>
            <Chip
              label={request.status}
              color={
                request.status === 'accepted' ? 'success' :
                request.status === 'rejected' ? 'error' :
                request.status === 'completed' ? 'default' :
                'primary'
              }
              sx={{ mr: 1 }}
            />
            <Chip
              label={request.type}
              variant="outlined"
              sx={{ mr: 1 }}
            />
            {request.type === 'group' && (
              <Chip
                label={`${request.participants.length}/${request.groupSize} participants`}
                variant="outlined"
              />
            )}
          </Box>

          <Typography variant="body2" sx={{ mb: 2 }}>
            {request.message}
          </Typography>

          {request.schedule && (
            <Box sx={{ mb: 2 }}>
              <Typography variant="subtitle2" gutterBottom>
                Scheduled Time:
              </Typography>
              <Typography variant="body2">
                {new Date(request.schedule.startDate).toLocaleDateString()} - 
                {new Date(request.schedule.endDate).toLocaleDateString()}
              </Typography>
            </Box>
          )}

          {request.status === 'accepted' && (
            <Box sx={{ mt: 2 }}>
              <Button
                variant="contained"
                color="primary"
                onClick={() => openChat(request)}
                sx={{ mr: 1 }}
              >
                Open Chat
              </Button>
              {!request.schedule && (
                <Button
                  variant="outlined"
                  onClick={() => {
                    setSelectedRequest(request);
                    setScheduleDialogOpen(true);
                  }}
                >
                  Schedule Session
                </Button>
              )}
            </Box>
          )}

          {request.status === 'pending' && value === 1 && (
            <Box sx={{ mt: 2 }}>
              <Button
                variant="contained"
                color="primary"
                onClick={() => handleRequestResponse(request._id, 'accepted')}
                sx={{ mr: 1 }}
              >
                Accept
              </Button>
              <Button
                variant="outlined"
                color="error"
                onClick={() => handleRequestResponse(request._id, 'rejected')}
              >
                Reject
              </Button>
            </Box>
          )}
        </CardContent>
      </Card>
    </Grid>
  );

  return (
    <Container maxWidth="lg" sx={{ py: 4 }}>
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Learning Requests
        </Typography>
        <Box sx={{ display: 'flex', gap: 2, mb: 3 }}>
          <TextField
            placeholder="Search requests..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            InputProps={{
              startAdornment: <SearchIcon color="action" sx={{ mr: 1 }} />
            }}
            sx={{ flexGrow: 1 }}
          />
          <IconButton
            onClick={() => setFilterDialogOpen(true)}
            color={Object.values(filters).some(v => v) ? 'primary' : 'default'}
          >
            <Badge
              badgeContent={Object.values(filters).filter(v => v).length}
              color="primary"
            >
              <FilterIcon />
            </Badge>
          </IconButton>
        </Box>
      </Box>

      <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
        <Tabs value={value} onChange={handleTabChange}>
          <Tab label="Outgoing Requests" />
          <Tab label="Incoming Requests" />
        </Tabs>
      </Box>

      <TabPanel value={value} index={0}>
        <Grid container spacing={3}>
          {filteredRequests
            .filter(request => request.from._id === currentUser._id)
            .map(renderRequestCard)}
        </Grid>
      </TabPanel>

      <TabPanel value={value} index={1}>
        <Grid container spacing={3}>
          {filteredRequests
            .filter(request => request.to._id === currentUser._id)
            .map(renderRequestCard)}
        </Grid>
      </TabPanel>

      {/* Filter Dialog */}
      <Dialog
        open={filterDialogOpen}
        onClose={() => setFilterDialogOpen(false)}
      >
        <DialogTitle>Filter Requests</DialogTitle>
        <DialogContent>
          <FormControl fullWidth sx={{ mb: 2 }}>
            <InputLabel>Status</InputLabel>
            <Select
              value={filters.status}
              onChange={(e) => handleFilterChange('status', e.target.value)}
              label="Status"
            >
              <MenuItem value="">All</MenuItem>
              <MenuItem value="pending">Pending</MenuItem>
              <MenuItem value="accepted">Accepted</MenuItem>
              <MenuItem value="rejected">Rejected</MenuItem>
              <MenuItem value="completed">Completed</MenuItem>
            </Select>
          </FormControl>

          <FormControl fullWidth sx={{ mb: 2 }}>
            <InputLabel>Type</InputLabel>
            <Select
              value={filters.type}
              onChange={(e) => handleFilterChange('type', e.target.value)}
              label="Type"
            >
              <MenuItem value="">All</MenuItem>
              <MenuItem value="individual">Individual</MenuItem>
              <MenuItem value="group">Group</MenuItem>
            </Select>
          </FormControl>

          <TextField
            fullWidth
            label="Skill"
            value={filters.skill}
            onChange={(e) => handleFilterChange('skill', e.target.value)}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setFilters({ status: '', type: '', skill: '' })}>
            Clear
          </Button>
          <Button onClick={() => setFilterDialogOpen(false)}>
            Apply
          </Button>
        </DialogActions>
      </Dialog>

      {/* Schedule Dialog */}
      <Dialog
        open={scheduleDialogOpen}
        onClose={() => setScheduleDialogOpen(false)}
      >
        <DialogTitle>Schedule Learning Session</DialogTitle>
        <DialogContent>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Start Date"
                type="date"
                value={schedule.startDate}
                onChange={(e) => setSchedule(prev => ({
                  ...prev,
                  startDate: e.target.value
                }))}
                InputLabelProps={{ shrink: true }}
                sx={{ mt: 2 }}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="End Date"
                type="date"
                value={schedule.endDate}
                onChange={(e) => setSchedule(prev => ({
                  ...prev,
                  endDate: e.target.value
                }))}
                InputLabelProps={{ shrink: true }}
                sx={{ mt: 2 }}
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setScheduleDialogOpen(false)}>
            Cancel
          </Button>
          <Button onClick={handleScheduleSubmit} variant="contained">
            Schedule
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
}
