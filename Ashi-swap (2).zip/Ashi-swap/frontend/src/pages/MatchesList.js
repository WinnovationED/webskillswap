import React, { useState, useEffect } from 'react';
import {
  Container,
  Grid,
  Card,
  CardContent,
  Typography,
  Button,
  Chip,
  Avatar
} from '@mui/material';
import axios from 'axios';
import { useAuth } from '../contexts/AuthContext';

function MatchesList() {
  const [matches, setMatches] = useState([]);
  const { user } = useAuth();

  useEffect(() => {
    fetchMatches();
  }, []);

  const fetchMatches = async () => {
    try {
      const response = await axios.get('http://localhost:5000/api/matches');
      setMatches(response.data);
    } catch (error) {
      console.error('Error fetching matches:', error);
    }
  };

  const handleStatusUpdate = async (matchId, status) => {
    try {
      await axios.patch(`http://localhost:5000/api/matches/${matchId}`, { status });
      fetchMatches();
    } catch (error) {
      console.error('Error updating match status:', error);
    }
  };

  return (
    <Container maxWidth="md" sx={{ mt: 4 }}>
      <Typography variant="h4" gutterBottom>
        Your Matches
      </Typography>

      <Grid container spacing={3}>
        {matches.map((match) => {
          const otherUser = match.user1._id === user?._id ? match.user2 : match.user1;
          
          return (
            <Grid item xs={12} key={match._id}>
              <Card>
                <CardContent>
                  <Grid container spacing={2} alignItems="center">
                    <Grid item>
                      <Avatar src={otherUser.profileImage} />
                    </Grid>
                    <Grid item xs>
                      <Typography variant="h6">
                        {otherUser.name}
                      </Typography>
                      <Typography color="textSecondary">
                        Skill: {match.skillExchanged.skillName}
                      </Typography>
                    </Grid>
                    <Grid item>
                      <Chip
                        label={match.status}
                        color={
                          match.status === 'accepted' ? 'success' :
                          match.status === 'pending' ? 'warning' :
                          'error'
                        }
                      />
                    </Grid>
                    {match.status === 'pending' && match.user2._id === user?._id && (
                      <Grid item>
                        <Button
                          variant="contained"
                          color="primary"
                          onClick={() => handleStatusUpdate(match._id, 'accepted')}
                          sx={{ mr: 1 }}
                        >
                          Accept
                        </Button>
                        <Button
                          variant="outlined"
                          color="error"
                          onClick={() => handleStatusUpdate(match._id, 'rejected')}
                        >
                          Reject
                        </Button>
                      </Grid>
                    )}
                  </Grid>
                </CardContent>
              </Card>
            </Grid>
          );
        })}
      </Grid>
    </Container>
  );
}

export default MatchesList;
