import React, { useState, useEffect } from 'react';
import {
  Container,
  Grid,
  Card,
  CardContent,
  Typography,
  Box,
  TextField,
  InputAdornment,
  Button,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Rating,
  Stack,
  useTheme,
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import FilterListIcon from '@mui/icons-material/FilterList';
import HandshakeIcon from '@mui/icons-material/Handshake';
import { useAuth } from '../contexts/AuthContext';
import SkillCard from '../components/SkillCard';

// Mock data for potential matches
const mockMatches = [
  {
    id: 1,
    skillName: 'Piano Lessons',
    skillType: 'teaching',
    description: 'Experienced piano teacher offering lessons for beginners to intermediate students.',
    tags: ['Music', 'Piano', 'Classical'],
    compatibility: 95,
    createdBy: {
      name: 'Sarah Wilson',
      rating: 4.8,
      profileImage: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah',
      skills: ['Piano', 'Music Theory'],
    },
    availability: {
      weekdays: ['Monday', 'Wednesday', 'Friday'],
      timeSlots: [{ startTime: '3:00 PM', endTime: '7:00 PM' }],
    },
  },
  {
    id: 2,
    skillName: 'JavaScript Development',
    skillType: 'teaching',
    description: 'Full-stack developer offering personalized JavaScript and React.js mentoring.',
    tags: ['Programming', 'JavaScript', 'React'],
    compatibility: 88,
    createdBy: {
      name: 'Mike Chen',
      rating: 4.9,
      profileImage: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Mike',
      skills: ['JavaScript', 'React', 'Node.js'],
    },
    availability: {
      weekdays: ['Tuesday', 'Thursday'],
      timeSlots: [{ startTime: '10:00 AM', endTime: '4:00 PM' }],
    },
  },
];

const MatchSkills = () => {
  const theme = useTheme();
  const { currentUser } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [matches, setMatches] = useState(mockMatches);
  const [selectedMatch, setSelectedMatch] = useState(null);
  const [matchDialogOpen, setMatchDialogOpen] = useState(false);

  const handleSearch = (event) => {
    const query = event.target.value.toLowerCase();
    setSearchQuery(query);
    
    // Filter matches based on search query
    const filteredMatches = mockMatches.filter(match => 
      match.skillName.toLowerCase().includes(query) ||
      match.description.toLowerCase().includes(query) ||
      match.tags.some(tag => tag.toLowerCase().includes(query))
    );
    
    setMatches(filteredMatches);
  };

  const handleMatchRequest = (match) => {
    setSelectedMatch(match);
    setMatchDialogOpen(true);
  };

  const handleConfirmMatch = () => {
    // TODO: Implement match confirmation logic
    console.log('Match confirmed with:', selectedMatch);
    setMatchDialogOpen(false);
  };

  return (
    <Box sx={{ py: { xs: 2, md: 4 } }}>
      <Container maxWidth="lg">
        {/* Header */}
        <Box sx={{ mb: 4 }}>
          <Typography variant="h4" gutterBottom>
            Find Your Perfect Match
          </Typography>
          <Typography variant="body1" color="text.secondary">
            Discover people who can teach what you want to learn, or learn what you can teach.
          </Typography>
        </Box>

        {/* Search and Filter */}
        <Box sx={{ mb: 4 }}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={8}>
              <TextField
                fullWidth
                placeholder="Search by skill, tag, or description..."
                value={searchQuery}
                onChange={handleSearch}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <SearchIcon color="action" />
                    </InputAdornment>
                  ),
                }}
                sx={{
                  bgcolor: 'background.paper',
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': { borderColor: 'transparent' },
                    '&:hover fieldset': { borderColor: 'divider' },
                    '&.Mui-focused fieldset': { borderColor: 'primary.main' },
                  },
                }}
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Button
                fullWidth
                variant="outlined"
                startIcon={<FilterListIcon />}
                sx={{ height: '100%' }}
              >
                Filters
              </Button>
            </Grid>
          </Grid>
        </Box>

        {/* Matches Grid */}
        <Grid container spacing={3}>
          {matches.map((match) => (
            <Grid item xs={12} md={6} key={match.id}>
              <Card
                sx={{
                  height: '100%',
                  display: 'flex',
                  flexDirection: 'column',
                  position: 'relative',
                }}
              >
                <Box
                  sx={{
                    position: 'absolute',
                    top: 16,
                    right: 16,
                    bgcolor: 'success.main',
                    color: 'white',
                    px: 2,
                    py: 0.5,
                    borderRadius: 2,
                    zIndex: 1,
                  }}
                >
                  <Typography variant="subtitle2">
                    {match.compatibility}% Match
                  </Typography>
                </Box>
                <CardContent>
                  <SkillCard
                    skill={match}
                    showMatchButton
                    onMatch={() => handleMatchRequest(match)}
                  />
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>

        {/* Match Confirmation Dialog */}
        <Dialog open={matchDialogOpen} onClose={() => setMatchDialogOpen(false)}>
          <DialogTitle>Confirm Skill Match</DialogTitle>
          <DialogContent>
            <Box sx={{ mb: 3 }}>
              <Typography variant="body1" paragraph>
                You're about to request a skill exchange with {selectedMatch?.createdBy.name}.
              </Typography>
              <Typography variant="body2" color="text.secondary">
                They will be notified of your interest and can choose to accept or decline the match.
              </Typography>
            </Box>
            <Box sx={{ mb: 2 }}>
              <Typography variant="subtitle2" gutterBottom>
                Availability
              </Typography>
              <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap>
                {selectedMatch?.availability.weekdays.map((day) => (
                  <Chip key={day} label={day} size="small" />
                ))}
              </Stack>
            </Box>
            <Box>
              <Typography variant="subtitle2" gutterBottom>
                Time Slots
              </Typography>
              <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap>
                {selectedMatch?.availability.timeSlots.map((slot, index) => (
                  <Chip
                    key={index}
                    label={`${slot.startTime} - ${slot.endTime}`}
                    size="small"
                  />
                ))}
              </Stack>
            </Box>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setMatchDialogOpen(false)}>Cancel</Button>
            <Button
              variant="contained"
              onClick={handleConfirmMatch}
              startIcon={<HandshakeIcon />}
            >
              Confirm Match
            </Button>
          </DialogActions>
        </Dialog>
      </Container>
    </Box>
  );
};

export default MatchSkills;
