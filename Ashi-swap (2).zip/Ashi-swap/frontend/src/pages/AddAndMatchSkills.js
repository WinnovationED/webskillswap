import React, { useState } from 'react';
import {
  Container,
  Box,
  Typography,
  Paper,
  Tab,
  Tabs,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
} from '@mui/material';
import AddSkillForm from '../components/AddSkillForm';
import MatchMaking from '../components/MatchMaking';
import { useAuth } from '../contexts/AuthContext';

function AddAndMatchSkills() {
  const [activeTab, setActiveTab] = useState(0);
  const [selectedSkill, setSelectedSkill] = useState(null);
  const [matchDialogOpen, setMatchDialogOpen] = useState(false);
  const { user } = useAuth();

  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };

  const handleSkillAdded = () => {
    // Switch to the Match tab after adding a skill
    setActiveTab(1);
  };

  const handleMatchClick = (skill) => {
    setSelectedSkill(skill);
    setMatchDialogOpen(true);
  };

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Typography variant="h4" gutterBottom>
        Skill Exchange Hub
      </Typography>

      <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 3 }}>
        <Tabs value={activeTab} onChange={handleTabChange}>
          <Tab label="Add Your Skills" />
          <Tab label="Find Matches" />
        </Tabs>
      </Box>

      {activeTab === 0 && (
        <Paper elevation={3} sx={{ p: 3 }}>
          <Typography variant="h6" gutterBottom>
            Add a New Skill
          </Typography>
          <AddSkillForm onSkillAdded={handleSkillAdded} />
        </Paper>
      )}

      {activeTab === 1 && (
        <Paper elevation={3} sx={{ p: 3 }}>
          <Typography variant="h6" gutterBottom>
            Find Your Perfect Match
          </Typography>
          <Box sx={{ mb: 2 }}>
            <Typography variant="body1" color="text.secondary">
              Select a skill to find potential matches based on availability and interests.
            </Typography>
          </Box>
          {selectedSkill && (
            <Dialog
              open={matchDialogOpen}
              onClose={() => setMatchDialogOpen(false)}
              maxWidth="md"
              fullWidth
            >
              <DialogTitle>
                Find Matches for {selectedSkill.skillName}
              </DialogTitle>
              <DialogContent>
                <MatchMaking
                  skill={selectedSkill}
                  onClose={() => setMatchDialogOpen(false)}
                />
              </DialogContent>
            </Dialog>
          )}
        </Paper>
      )}
    </Container>
  );
}

export default AddAndMatchSkills;
