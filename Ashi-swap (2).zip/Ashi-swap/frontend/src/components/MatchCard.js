import React from 'react';
import {
  Card,
  CardContent,
  CardActions,
  Typography,
  Button,
  Box,
  Avatar,
  AvatarGroup,
  Chip,
  useTheme,
  Collapse,
  IconButton,
} from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import styled from '@emotion/styled';

const ExpandMore = styled((props) => {
  const { expand, ...other } = props;
  return <IconButton {...other} />;
})(({ theme, expand }) => ({
  transform: !expand ? 'rotate(0deg)' : 'rotate(180deg)',
  marginLeft: 'auto',
  transition: theme.transitions.create('transform', {
    duration: theme.transitions.duration.shortest,
  }),
}));

const MatchCard = ({ match, onRequestMatch }) => {
  const [expanded, setExpanded] = React.useState(false);
  const theme = useTheme();

  const handleExpandClick = () => {
    setExpanded(!expanded);
  };

  const getSkillImage = (skillName) => {
    const seed = encodeURIComponent(skillName.toLowerCase());
    return `https://api.dicebear.com/7.x/identicon/svg?seed=${seed}&backgroundColor=${theme.palette.primary.main.substring(1)}`;
  };

  return (
    <Card
      sx={{
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        transition: 'transform 0.2s ease-in-out',
        '&:hover': {
          transform: 'translateY(-4px)',
        },
      }}
    >
      <Box sx={{ position: 'relative' }}>
        <Box
          sx={{
            height: 140,
            overflow: 'hidden',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            bgcolor: 'grey.100',
          }}
        >
          <Box
            component="img"
            src={getSkillImage(match.skillWanted.skillName)}
            alt={match.skillWanted.skillName}
            sx={{
              width: '100%',
              height: '100%',
              objectFit: 'cover',
            }}
          />
        </Box>
        <AvatarGroup
          max={3}
          sx={{
            position: 'absolute',
            bottom: -20,
            right: 16,
            '& .MuiAvatar-root': {
              border: `2px solid ${theme.palette.background.paper}`,
            },
          }}
        >
          {match.potentialMatches.map((potential, index) => (
            <Avatar
              key={index}
              src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${potential.createdBy.name}`}
              alt={potential.createdBy.name}
            />
          ))}
        </AvatarGroup>
      </Box>

      <CardContent sx={{ pt: 3, flexGrow: 1 }}>
        <Typography variant="h5" gutterBottom>
          {match.skillWanted.skillName}
        </Typography>

        <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
          <Chip
            label={`${match.potentialMatches.length} potential ${
              match.potentialMatches.length === 1 ? 'match' : 'matches'
            }`}
            color="primary"
            size="small"
            sx={{ mr: 1 }}
          />
        </Box>

        <Box sx={{ mt: 2 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
            <CalendarMonthIcon sx={{ mr: 1, color: 'primary.main' }} />
            <Typography variant="body2">
              {match.skillWanted.availability.weekdays.join(', ')}
            </Typography>
          </Box>

          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <AccessTimeIcon sx={{ mr: 1, color: 'primary.main' }} />
            <Typography variant="body2">
              {match.skillWanted.availability.timeSlots[0]?.startTime} -{' '}
              {match.skillWanted.availability.timeSlots[0]?.endTime}
            </Typography>
          </Box>
        </Box>
      </CardContent>

      <CardActions sx={{ justifyContent: 'space-between', p: 2 }}>
        <Button
          variant="contained"
          color="primary"
          onClick={() => onRequestMatch(match)}
          size="small"
        >
          View Matches
        </Button>
        <ExpandMore
          expand={expanded}
          onClick={handleExpandClick}
          aria-expanded={expanded}
          aria-label="show more"
        >
          <ExpandMoreIcon />
        </ExpandMore>
      </CardActions>

      <Collapse in={expanded} timeout="auto" unmountOnExit>
        <CardContent>
          <Typography variant="h6" gutterBottom>
            Potential Matches
          </Typography>
          {match.potentialMatches.map((potential, index) => (
            <Box
              key={index}
              sx={{
                display: 'flex',
                alignItems: 'center',
                mb: 2,
                p: 1,
                borderRadius: 1,
                bgcolor: 'grey.50',
              }}
            >
              <Avatar
                src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${potential.createdBy.name}`}
                sx={{ mr: 2 }}
              />
              <Box sx={{ flexGrow: 1 }}>
                <Typography variant="subtitle2">
                  {potential.createdBy.name}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Available: {potential.availability.weekdays.join(', ')}
                </Typography>
              </Box>
              <Button
                variant="outlined"
                size="small"
                onClick={() => onRequestMatch(match, potential)}
              >
                Request
              </Button>
            </Box>
          ))}
        </CardContent>
      </Collapse>
    </Card>
  );
};

export default MatchCard;
