import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Tabs,
  Tab,
  Card,
  CardContent,
  CardActions,
  Button,
  Chip,
  Avatar,
  Rating,
  Snackbar,
  Alert,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  CircularProgress,
  Grid,
  Badge,
  IconButton,
} from '@mui/material';
import { useAuth } from '../contexts/AuthContext';
import api from '../utils/api';
import notificationService from '../services/notificationService';
import ChatIcon from '@mui/icons-material/Chat';
import VideocamIcon from '@mui/icons-material/Videocam';

// Add WebRTC configuration
const configuration = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
  ],
};

function TabPanel({ children, value, index, ...other }) {
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`match-tabpanel-${index}`}
      aria-labelledby={`match-tab-${index}`}
      {...other}
    >
      {value === index && <Box sx={{ p: 3 }}>{children}</Box>}
    </div>
  );
}

function MatchManager() {
  const { currentUser } = useAuth();
  const [value, setValue] = useState(0);
  const [matches, setMatches] = useState([]);
  const [suggestions, setSuggestions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });
  const [selectedMatch, setSelectedMatch] = useState(null);
  const [confirmDialogOpen, setConfirmDialogOpen] = useState(false);
  const [newMatchCount, setNewMatchCount] = useState(0);
  const [chatOpen, setChatOpen] = useState(false);
  const [videoCallOpen, setVideoCallOpen] = useState(false);
  const [localStream, setLocalStream] = useState(null);
  const [remoteStream, setRemoteStream] = useState(null);
  const [peerConnection, setPeerConnection] = useState(null);

  // Initialize WebRTC
  const initializeWebRTC = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true,
      });
      setLocalStream(stream);
      
      const pc = new RTCPeerConnection(configuration);
      setPeerConnection(pc);

      // Add local stream to peer connection
      stream.getTracks().forEach(track => {
        pc.addTrack(track, stream);
      });

      // Handle remote stream
      pc.ontrack = (event) => {
        setRemoteStream(event.streams[0]);
      };

      // Handle ICE candidates
      pc.onicecandidate = (event) => {
        if (event.candidate) {
          // In a real application, you would send this to the other peer
          console.log('ICE candidate:', event.candidate);
        }
      };
    } catch (error) {
      console.error('Error initializing WebRTC:', error);
    }
  };

  // Handle chat open/close
  const handleChatOpen = (match) => {
    setSelectedMatch(match);
    setChatOpen(true);
  };

  const handleChatClose = () => {
    setChatOpen(false);
    setSelectedMatch(null);
  };

  // Handle video call
  const handleVideoCall = async (match) => {
    setSelectedMatch(match);
    await initializeWebRTC();
    setVideoCallOpen(true);
  };

  const handleVideoCallClose = () => {
    if (peerConnection) {
      peerConnection.close();
    }
    if (localStream) {
      localStream.getTracks().forEach(track => track.stop());
    }
    setPeerConnection(null);
    setLocalStream(null);
    setRemoteStream(null);
    setVideoCallOpen(false);
    setSelectedMatch(null);
  };

  useEffect(() => {
    if (currentUser) {
      fetchMatches();
      fetchSuggestions();
      
      // Connect to notification service
      notificationService.connect(currentUser._id);
      
      // Setup notification handlers
      notificationService.onNewMatch((data) => {
        setSnackbar({
          open: true,
          message: `New match found with ${data.teacherName} for ${data.skillName}!`,
          severity: 'success'
        });
        setNewMatchCount(prev => prev + 1);
        fetchSuggestions(); // Refresh suggestions
      });

      notificationService.onMatchUpdate((data) => {
        setSnackbar({
          open: true,
          message: `Match ${data.status} by ${data.userName}`,
          severity: data.status === 'accepted' ? 'success' : 'info'
        });
        fetchMatches(); // Refresh matches
      });

      notificationService.onMatchRequest((data) => {
        setSnackbar({
          open: true,
          message: `New match request from ${data.studentName} for ${data.skillName}`,
          severity: 'info'
        });
        fetchMatches(); // Refresh matches
      });

      // Cleanup
      return () => {
        notificationService.disconnect();
      };
    }
  }, [currentUser]);

  const fetchMatches = async () => {
    try {
      const response = await api.get('/api/matches');
      setMatches(response.data);
    } catch (err) {
      setError('Failed to load matches');
      console.error('Error fetching matches:', err);
    }
  };

  const fetchSuggestions = async () => {
    try {
      const response = await api.get('/api/matches/suggestions');
      setSuggestions(response.data);
    } catch (err) {
      setError('Failed to load suggestions');
      console.error('Error fetching suggestions:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleTabChange = (event, newValue) => {
    setValue(newValue);
    if (newValue === 0) {
      setNewMatchCount(0); // Reset new match count when viewing suggestions
    }
  };

  const handleMatchRequest = (match) => {
    setSelectedMatch(match);
    setConfirmDialogOpen(true);
  };

  const confirmMatchRequest = async () => {
    try {
      await api.post('/api/matches', {
        teacherId: selectedMatch.teacher._id,
        skillId: selectedMatch.teachingSkill._id
      });
      
      setSuggestions(suggestions.filter(m => 
        m.teachingSkill._id !== selectedMatch.teachingSkill._id ||
        m.teacher._id !== selectedMatch.teacher._id
      ));
      
      setConfirmDialogOpen(false);
      setSelectedMatch(null);
      setSnackbar({
        open: true,
        message: 'Match request sent successfully!',
        severity: 'success'
      });
      
      // Refresh matches
      fetchMatches();
    } catch (err) {
      setSnackbar({
        open: true,
        message: 'Failed to send match request',
        severity: 'error'
      });
    }
  };

  const handleMatchResponse = async (matchId, status) => {
    try {
      await api.patch(`/api/matches/${matchId}`, { status });
      setMatches(matches.map(m => 
        m._id === matchId ? { ...m, status } : m
      ));
      setSnackbar({
        open: true,
        message: `Match ${status} successfully!`,
        severity: 'success'
      });
    } catch (err) {
      setSnackbar({
        open: true,
        message: `Failed to ${status} match`,
        severity: 'error'
      });
    }
  };

  const renderMatchCard = (match, index) => {
    if (!match || !match.teacher) return null;

    return (
      <Grid item xs={12} md={6} key={index}>
        <Card>
          <CardContent>
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
              <Avatar
                src={match.teacher?.profileImage || ''}
                alt={match.teacher?.name || 'User'}
                sx={{ width: 56, height: 56, mr: 2 }}
              />
              <Box>
                <Typography variant="h6">
                  {match.teacher?.name || 'Unknown User'}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Teaching {match.teachingSkill?.skillName || 'Unknown Skill'}
                </Typography>
              </Box>
            </Box>

            {match.score !== undefined && (
              <Typography variant="subtitle1" gutterBottom>
                Match Score: {match.score.toFixed(2)}
              </Typography>
            )}

            {match.commonDays && match.commonDays.length > 0 && (
              <Box sx={{ mb: 2 }}>
                <Typography variant="subtitle2" gutterBottom>
                  Common Availability:
                </Typography>
                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                  {match.commonDays.map((day, idx) => (
                    <Chip key={idx} label={day} size="small" color="primary" />
                  ))}
                </Box>
              </Box>
            )}

            {match.teachingSkill?.averageRating !== undefined && (
              <Box sx={{ mb: 2 }}>
                <Typography variant="subtitle2" gutterBottom>
                  Teacher's Rating:
                </Typography>
                <Rating
                  value={match.teachingSkill.averageRating || 0}
                  precision={0.5}
                  readOnly
                />
              </Box>
            )}

            {match.commonTags > 0 && match.teachingSkill?.tags && (
              <Box>
                <Typography variant="subtitle2" gutterBottom>
                  Common Interests:
                </Typography>
                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                  {match.teachingSkill.tags.map((tag, idx) => (
                    <Chip
                      key={idx}
                      label={tag}
                      size="small"
                      color={match.learningSkill?.tags?.includes(tag) ? "primary" : "default"}
                    />
                  ))}
                </Box>
              </Box>
            )}
          </CardContent>
          <CardActions>
            <Button
              variant="contained"
              color="primary"
              onClick={() => handleMatchRequest(match)}
            >
              Request to Learn
            </Button>
            <IconButton
              onClick={() => handleChatOpen(match)}
              color="primary"
              aria-label="chat"
            >
              <ChatIcon />
            </IconButton>
            <IconButton
              onClick={() => handleVideoCall(match)}
              color="primary"
              aria-label="video call"
            >
              <VideocamIcon />
            </IconButton>
          </CardActions>
        </Card>
      </Grid>
    );
  };

  const renderActiveMatchCard = (match, index) => {
    if (!match || !match.teacher) return null;

    return (
      <Grid item xs={12} md={6} key={index}>
        <Card>
          <CardContent>
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
              <Avatar
                src={match.teacher?.profileImage || ''}
                alt={match.teacher?.name || 'User'}
                sx={{ width: 56, height: 56, mr: 2 }}
              />
              <Box>
                <Typography variant="h6">
                  {match.teacher?.name || 'Unknown User'}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Teaching {match.teachingSkill?.skillName || 'Unknown Skill'}
                </Typography>
              </Box>
            </Box>

            <Typography variant="subtitle1" color="text.secondary" gutterBottom>
              Status: {match.status || 'Unknown'}
            </Typography>

            {match.commonDays && match.commonDays.length > 0 && (
              <Box sx={{ mb: 2 }}>
                <Typography variant="subtitle2" gutterBottom>
                  Common Availability:
                </Typography>
                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                  {match.commonDays.map((day, idx) => (
                    <Chip key={idx} label={day} size="small" color="primary" />
                  ))}
                </Box>
              </Box>
            )}
          </CardContent>
          {match.status === 'pending' && (
            <CardActions>
              <Button
                variant="contained"
                color="primary"
                onClick={() => handleMatchResponse(match._id, 'accepted')}
              >
                Accept
              </Button>
              <Button
                variant="outlined"
                color="error"
                onClick={() => handleMatchResponse(match._id, 'rejected')}
              >
                Reject
              </Button>
            </CardActions>
          )}
          <CardActions>
            <IconButton
              onClick={() => handleChatOpen(match)}
              color="primary"
              aria-label="chat"
            >
              <ChatIcon />
            </IconButton>
            <IconButton
              onClick={() => handleVideoCall(match)}
              color="primary"
              aria-label="video call"
            >
              <VideocamIcon />
            </IconButton>
          </CardActions>
        </Card>
      </Grid>
    );
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '80vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box sx={{ width: '100%' }}>
      <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
        <Tabs value={value} onChange={handleTabChange} aria-label="match management tabs">
          <Tab 
            label={
              <Badge badgeContent={newMatchCount} color="error">
                Suggestions
              </Badge>
            } 
            id="match-tab-0" 
            aria-controls="match-tabpanel-0" 
          />
          <Tab label="Active Matches" id="match-tab-1" aria-controls="match-tabpanel-1" />
        </Tabs>
      </Box>

      {error && (
        <Alert severity="error" sx={{ mt: 2 }}>
          {error}
        </Alert>
      )}

      <TabPanel value={value} index={0}>
        <Grid container spacing={3}>
          {suggestions.length === 0 ? (
            <Grid item xs={12}>
              <Alert severity="info">
                No match suggestions found. Try adding more skills you want to learn!
              </Alert>
            </Grid>
          ) : (
            suggestions.map((match, index) => renderMatchCard(match, index))
          )}
        </Grid>
      </TabPanel>

      <TabPanel value={value} index={1}>
        <Grid container spacing={3}>
          {matches.length === 0 ? (
            <Grid item xs={12}>
              <Alert severity="info">
                No active matches yet. Try requesting matches from the suggestions tab!
              </Alert>
            </Grid>
          ) : (
            matches.map((match, index) => renderActiveMatchCard(match, index))
          )}
        </Grid>
      </TabPanel>

      <Dialog
        open={confirmDialogOpen}
        onClose={() => setConfirmDialogOpen(false)}
      >
        <DialogTitle>Confirm Match Request</DialogTitle>
        <DialogContent>
          <Typography>
            Are you sure you want to request a match with {selectedMatch?.teacher?.name || 'this teacher'} for learning {selectedMatch?.teachingSkill?.skillName || 'this skill'}?
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setConfirmDialogOpen(false)}>Cancel</Button>
          <Button onClick={confirmMatchRequest} variant="contained" color="primary">
            Confirm
          </Button>
        </DialogActions>
      </Dialog>

      {/* Chat Dialog */}
      <Dialog open={chatOpen} onClose={handleChatClose} maxWidth="sm" fullWidth>
        <DialogTitle>
          Chat with {selectedMatch?.teacher?.name}
        </DialogTitle>
        <DialogContent>
          {/* Simple chat interface */}
          <Box sx={{ height: 400, overflowY: 'auto', mb: 2 }}>
            {/* Messages will be displayed here */}
          </Box>
          <Box sx={{ display: 'flex', gap: 1 }}>
            <input
              type="text"
              placeholder="Type your message..."
              style={{ flex: 1, padding: '8px', borderRadius: '4px', border: '1px solid #ccc' }}
            />
            <Button variant="contained" color="primary">
              Send
            </Button>
          </Box>
        </DialogContent>
      </Dialog>

      {/* Video Call Dialog */}
      <Dialog open={videoCallOpen} onClose={handleVideoCallClose} maxWidth="md" fullWidth>
        <DialogTitle>
          Video Call with {selectedMatch?.teacher?.name}
        </DialogTitle>
        <DialogContent>
          <Grid container spacing={2}>
            <Grid item xs={6}>
              {localStream && (
                <video
                  autoPlay
                  playsInline
                  style={{ width: '100%', height: 'auto', borderRadius: '8px', border: '1px solid #ccc' }}
                  ref={(el) => el && el.srcObject === localStream}
                />
              )}
            </Grid>
            <Grid item xs={6}>
              {remoteStream && (
                <video
                  autoPlay
                  playsInline
                  style={{ width: '100%', height: 'auto', borderRadius: '8px', border: '1px solid #ccc' }}
                  ref={(el) => el && el.srcObject === remoteStream}
                />
              )}
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleVideoCallClose} color="error">
            End Call
          </Button>
        </DialogActions>
      </Dialog>

      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
      >
        <Alert
          onClose={() => setSnackbar({ ...snackbar, open: false })}
          severity={snackbar.severity}
          sx={{ width: '100%' }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
}

export default MatchManager;
