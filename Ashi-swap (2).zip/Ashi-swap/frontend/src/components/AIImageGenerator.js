import React, { useState } from 'react';
import {
  Box,
  Button,
  CircularProgress,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Typography,
  Card,
  CardMedia,
  IconButton,
} from '@mui/material';
import { Close as CloseIcon, Refresh as RefreshIcon } from '@mui/icons-material';
import axios from 'axios';

function AIImageGenerator({ open, onClose, onImageSelect }) {
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [images, setImages] = useState([]);
  const [error, setError] = useState('');

  const generateImages = async () => {
    try {
      setLoading(true);
      setError('');
      
      // Replace this with your actual AI image generation API endpoint
      const response = await axios.post('http://localhost:5000/api/generate-images', {
        prompt,
        n: 4 // Generate 4 variations
      });

      setImages(response.data.images);
    } catch (error) {
      console.error('Error generating images:', error);
      setError('Failed to generate images. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleImageSelect = (imageUrl) => {
    onImageSelect(imageUrl);
    onClose();
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          Generate AI Images
          <IconButton onClick={onClose} size="small">
            <CloseIcon />
          </IconButton>
        </Box>
      </DialogTitle>
      <DialogContent>
        <Box sx={{ p: 2 }}>
          <TextField
            fullWidth
            label="Describe the image you want"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            multiline
            rows={2}
            placeholder="E.g., A professional profile photo with a modern background"
            sx={{ mb: 2 }}
          />
          <Button
            variant="contained"
            onClick={generateImages}
            disabled={!prompt.trim() || loading}
            startIcon={loading ? <CircularProgress size={20} /> : <RefreshIcon />}
          >
            Generate Images
          </Button>
          {error && (
            <Typography color="error" sx={{ mt: 2 }}>
              {error}
            </Typography>
          )}
          <Box sx={{ mt: 3, display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 2 }}>
            {images.map((imageUrl, index) => (
              <Card
                key={index}
                sx={{
                  cursor: 'pointer',
                  transition: 'transform 0.2s',
                  '&:hover': {
                    transform: 'scale(1.05)',
                  },
                }}
                onClick={() => handleImageSelect(imageUrl)}
              >
                <CardMedia
                  component="img"
                  height="200"
                  image={imageUrl}
                  alt={`Generated image ${index + 1}`}
                  sx={{ objectFit: 'cover' }}
                />
              </Card>
            ))}
          </Box>
        </Box>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
      </DialogActions>
    </Dialog>
  );
}

export default AIImageGenerator;
