import React, { useState, useEffect } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  Avatar,
  Grid,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Rating,
  TextField,
  Alert,
  CircularProgress,
} from '@mui/material';
import HandshakeIcon from '@mui/icons-material/Handshake';
import MessageIcon from '@mui/icons-material/Message';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import axios from 'axios';
import { useAuth } from '../contexts/AuthContext';

function MatchMaking({ skill, onClose }) {
  const { user } = useAuth();
  const [potentialMatches, setPotentialMatches] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedMatch, setSelectedMatch] = useState(null);
  const [messageDialogOpen, setMessageDialogOpen] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    fetchPotentialMatches();
  }, [skill]);

  const fetchPotentialMatches = async () => {
    try {
      const response = await axios.get(`http://localhost:5000/api/skills/matches/${skill._id}`);
      setPotentialMatches(response.data);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching matches:', error);
      setLoading(false);
    }
  };

  const handleRequestMatch = async (matchedUser) => {
    setSelectedMatch(matchedUser);
    setMessageDialogOpen(true);
  };

  const handleSendRequest = async () => {
    try {
      await axios.post('http://localhost:5000/api/matches/request', {
        skillId: skill._id,
        matchedUserId: selectedMatch._id,
        message: message,
      });
      setSuccess('Match request sent successfully!');
      setMessageDialogOpen(false);
      setMessage('');
      // Optionally, refresh the matches
      fetchPotentialMatches();
    } catch (error) {
      setError(error.response?.data?.error || 'Error sending match request');
    }
  };

  const calculateMatchScore = (matchedSkill) => {
    let score = 0;
    // Check days overlap
    const commonDays = skill.availability.weekdays.filter(day => 
      matchedSkill.availability.weekdays.includes(day)
    );
    score += (commonDays.length / 7) * 100;
    return Math.round(score);
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', p: 4 }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box>
      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
      {success && <Alert severity="success" sx={{ mb: 2 }}>{success}</Alert>}

      <Grid container spacing={3}>
        {potentialMatches.map((match) => (
          <Grid item xs={12} md={6} key={match._id}>
            <Card
              sx={{
                height: '100%',
                display: 'flex',
                flexDirection: 'column',
                transition: 'transform 0.2s',
                '&:hover': {
                  transform: 'translateY(-4px)',
                },
              }}
            >
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <Avatar
                    src={match.createdBy.profileImage || `https://api.dicebear.com/7.x/avataaars/svg?seed=${match.createdBy.name}`}
                    sx={{ width: 56, height: 56, mr: 2 }}
                  />
                  <Box>
                    <Typography variant="h6">{match.createdBy.name}</Typography>
                    <Chip
                      label={`${calculateMatchScore(match)}% Match`}
                      color="primary"
                      size="small"
                    />
                  </Box>
                </Box>

                <Box sx={{ mb: 2 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                    <CalendarMonthIcon sx={{ mr: 1, color: 'primary.main' }} />
                    <Typography variant="body2">
                      Available: {match.availability.weekdays.join(', ')}
                    </Typography>
                  </Box>
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <AccessTimeIcon sx={{ mr: 1, color: 'primary.main' }} />
                    <Typography variant="body2">
                      Time: {match.availability.timeSlots[0]?.startTime} - {match.availability.timeSlots[0]?.endTime}
                    </Typography>
                  </Box>
                </Box>

                <Box sx={{ display: 'flex', gap: 1, mt: 2 }}>
                  <Button
                    variant="contained"
                    startIcon={<HandshakeIcon />}
                    onClick={() => handleRequestMatch(match.createdBy)}
                    fullWidth
                  >
                    Request Match
                  </Button>
                  <Button
                    variant="outlined"
                    startIcon={<MessageIcon />}
                    onClick={() => handleRequestMatch(match.createdBy)}
                  >
                    Message
                  </Button>
                </Box>
              </CardContent>
            </Card>
          </Grid>
        ))}

        {potentialMatches.length === 0 && (
          <Grid item xs={12}>
            <Box
              sx={{
                textAlign: 'center',
                py: 8,
                bgcolor: 'background.paper',
                borderRadius: 2,
              }}
            >
              <Typography variant="h6" color="text.secondary">
                No potential matches found at the moment
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                Try adjusting your availability or check back later
              </Typography>
            </Box>
          </Grid>
        )}
      </Grid>

      <Dialog open={messageDialogOpen} onClose={() => setMessageDialogOpen(false)}>
        <DialogTitle>Send Match Request</DialogTitle>
        <DialogContent>
          <Typography variant="body2" sx={{ mb: 2 }}>
            Send a message to {selectedMatch?.name} explaining why you'd like to connect
          </Typography>
          <TextField
            fullWidth
            multiline
            rows={4}
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Introduce yourself and explain what you hope to learn/teach..."
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setMessageDialogOpen(false)}>Cancel</Button>
          <Button
            variant="contained"
            onClick={handleSendRequest}
            disabled={!message.trim()}
          >
            Send Request
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}

export default MatchMaking;
