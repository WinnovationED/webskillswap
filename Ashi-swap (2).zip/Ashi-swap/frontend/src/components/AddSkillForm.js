import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Box,
  Chip,
  Typography,
  Grid,
  Alert,
} from '@mui/material';

const weekDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

const AddSkillForm = ({ open, onClose, onSubmit, initialData }) => {
  const [error, setError] = useState('');
  const [skill, setSkill] = useState({
    skillName: '',
    description: '',
    skillType: 'teaching',
    tags: [],
    availability: {
      weekdays: [],
      timeSlots: [{ startTime: '09:00', endTime: '17:00' }],
    },
  });

  const [newTag, setNewTag] = useState('');

  useEffect(() => {
    if (initialData) {
      setSkill({
        skillName: initialData.skillName || '',
        description: initialData.description || '',
        skillType: initialData.skillType || 'teaching',
        tags: initialData.tags || [],
        availability: {
          weekdays: initialData.availability?.weekdays || [],
          timeSlots: initialData.availability?.timeSlots || [{ startTime: '09:00', endTime: '17:00' }],
        },
      });
    } else {
      resetForm();
    }
  }, [initialData]);

  const resetForm = () => {
    setSkill({
      skillName: '',
      description: '',
      skillType: 'teaching',
      tags: [],
      availability: {
        weekdays: [],
        timeSlots: [{ startTime: '09:00', endTime: '17:00' }],
      },
    });
    setError('');
    setNewTag('');
  };

  const handleInputChange = (field) => (event) => {
    setSkill({ ...skill, [field]: event.target.value });
  };

  const handleTimeChange = (index, type) => (event) => {
    const updatedTimeSlots = [...skill.availability.timeSlots];
    updatedTimeSlots[index] = {
      ...updatedTimeSlots[index],
      [type]: event.target.value,
    };
    setSkill({
      ...skill,
      availability: {
        ...skill.availability,
        timeSlots: updatedTimeSlots,
      },
    });
  };

  const handleWeekdayToggle = (day) => {
    const weekdays = skill.availability.weekdays.includes(day)
      ? skill.availability.weekdays.filter(d => d !== day)
      : [...skill.availability.weekdays, day];
    setSkill({
      ...skill,
      availability: {
        ...skill.availability,
        weekdays,
      },
    });
  };

  const handleAddTag = (event) => {
    if (event.key === 'Enter' && newTag.trim()) {
      if (!skill.tags.includes(newTag.trim())) {
        setSkill({
          ...skill,
          tags: [...skill.tags, newTag.trim()],
        });
      }
      setNewTag('');
    }
  };

  const handleRemoveTag = (tagToRemove) => {
    setSkill({
      ...skill,
      tags: skill.tags.filter(tag => tag !== tagToRemove),
    });
  };

  const validateForm = () => {
    if (!skill.skillName.trim()) {
      setError('Skill name is required');
      return false;
    }
    if (!skill.description.trim()) {
      setError('Description is required');
      return false;
    }
    if (skill.availability.weekdays.length === 0) {
      setError('Please select at least one weekday');
      return false;
    }
    setError('');
    return true;
  };

  const handleSubmit = async () => {
    if (!validateForm()) return;

    try {
      await onSubmit(skill);
      resetForm();
    } catch (err) {
      setError(err.message);
    }
  };

  const handleClose = () => {
    resetForm();
    onClose();
  };

  return (
    <Dialog 
      open={open} 
      onClose={handleClose} 
      maxWidth="md" 
      fullWidth
      aria-labelledby="skill-dialog-title"
      disableEscapeKeyDown={false}
      keepMounted={false}
    >
      <DialogTitle id="skill-dialog-title">
        {initialData ? 'Edit Skill' : 'Add New Skill'}
      </DialogTitle>
      <DialogContent>
        {error && (
          <Alert severity="error" sx={{ mb: 2 }}>
            {error}
          </Alert>
        )}
        <Grid container spacing={3} sx={{ mt: 0 }}>
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              label="Skill Name"
              value={skill.skillName}
              onChange={handleInputChange('skillName')}
              required
              error={!skill.skillName.trim()}
              helperText={!skill.skillName.trim() ? 'Skill name is required' : ''}
              autoFocus
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl fullWidth>
              <InputLabel id="skill-type-label">Type</InputLabel>
              <Select
                labelId="skill-type-label"
                value={skill.skillType}
                label="Type"
                onChange={handleInputChange('skillType')}
              >
                <MenuItem value="teaching">Teaching</MenuItem>
                <MenuItem value="learning">Learning</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12}>
            <TextField
              fullWidth
              label="Description"
              value={skill.description}
              onChange={handleInputChange('description')}
              multiline
              rows={3}
              required
              error={!skill.description.trim()}
              helperText={!skill.description.trim() ? 'Description is required' : ''}
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              fullWidth
              label="Add Tags (Press Enter)"
              value={newTag}
              onChange={(e) => setNewTag(e.target.value)}
              onKeyDown={handleAddTag}
              placeholder="e.g., Programming, Music, Language"
            />
            <Box sx={{ mt: 1, display: 'flex', flexWrap: 'wrap', gap: 1 }}>
              {skill.tags.map((tag) => (
                <Chip
                  key={tag}
                  label={tag}
                  onDelete={() => handleRemoveTag(tag)}
                />
              ))}
            </Box>
          </Grid>
          <Grid item xs={12}>
            <Typography variant="subtitle1" gutterBottom>
              Availability
            </Typography>
            <Box sx={{ mb: 2, display: 'flex', flexWrap: 'wrap', gap: 1 }}>
              {weekDays.map((day) => (
                <Chip
                  key={day}
                  label={day}
                  onClick={() => handleWeekdayToggle(day)}
                  color={skill.availability.weekdays.includes(day) ? 'primary' : 'default'}
                />
              ))}
            </Box>
            {skill.availability.weekdays.length === 0 && (
              <Typography color="error" variant="caption">
                Please select at least one weekday
              </Typography>
            )}
          </Grid>
          <Grid item xs={12}>
            <Typography variant="subtitle2" gutterBottom>
              Time Slots
            </Typography>
            <Box sx={{ display: 'flex', gap: 2, alignItems: 'center' }}>
              <TextField
                label="Start Time"
                type="time"
                value={skill.availability.timeSlots[0].startTime}
                onChange={handleTimeChange(0, 'startTime')}
                InputLabelProps={{
                  shrink: true,
                }}
                inputProps={{
                  step: 300, // 5 min
                }}
                sx={{ width: 150 }}
              />
              <Typography>to</Typography>
              <TextField
                label="End Time"
                type="time"
                value={skill.availability.timeSlots[0].endTime}
                onChange={handleTimeChange(0, 'endTime')}
                InputLabelProps={{
                  shrink: true,
                }}
                inputProps={{
                  step: 300, // 5 min
                }}
                sx={{ width: 150 }}
              />
            </Box>
          </Grid>
        </Grid>
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose}>Cancel</Button>
        <Button 
          onClick={handleSubmit} 
          variant="contained" 
          color="primary"
          type="submit"
        >
          {initialData ? 'Save Changes' : 'Add Skill'}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default AddSkillForm;
