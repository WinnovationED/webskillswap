import React from 'react';
import { Box, Container, useTheme, useMediaQuery } from '@mui/material';
import Navbar from './Navbar';

function Layout({ children }) {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));

  return (
    <Box
      sx={{
        minHeight: '100vh',
        display: 'flex',
        flexDirection: 'column',
        bgcolor: 'background.default',
      }}
    >
      <Navbar />
      <Box
        component="main"
        sx={{
          flex: 1,
          py: isMobile ? 2 : 4,
          px: isMobile ? 2 : 3,
        }}
      >
        <Container
          maxWidth="lg"
          sx={{
            height: '100%',
          }}
        >
          {children}
        </Container>
      </Box>
    </Box>
  );
}

export default Layout;
