import React, { useState, useEffect } from 'react';
import {
  Container,
  Grid,
  Typography,
  Box,
  Button,
  Card,
  CardContent,
  CardActions,
  Chip,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Tab,
  Tabs,
} from '@mui/material';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import { useAuth } from '../contexts/AuthContext';

function UserSkills() {
  const { currentUser } = useAuth();
  const [userSkills, setUserSkills] = useState({ learning: [], teaching: [] });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [selectedTab, setSelectedTab] = useState(0);
  const [editSkill, setEditSkill] = useState(null);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [skillToDelete, setSkillToDelete] = useState(null);

  const [editForm, setEditForm] = useState({
    name: '',
    description: '',
    proficiencyLevel: 'beginner',
    category: '',
    tags: '',
  });

  useEffect(() => {
    fetchUserSkills();
  }, [currentUser]);

  const fetchUserSkills = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/skills/user-skills', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
        },
      });

      if (!response.ok) {
        throw new Error('Failed to fetch skills');
      }

      const data = await response.json();
      setUserSkills(data);
      setError('');
    } catch (error) {
      console.error('Error fetching skills:', error);
      setError('Failed to load skills');
    } finally {
      setLoading(false);
    }
  };

  const handleEditClick = (skill) => {
    setEditSkill(skill);
    setEditForm({
      name: skill.name,
      description: skill.description || '',
      proficiencyLevel: skill.proficiencyLevel || 'beginner',
      category: skill.category || '',
      tags: (skill.tags || []).join(', '),
    });
    setEditDialogOpen(true);
  };

  const handleDeleteClick = (skill) => {
    setSkillToDelete(skill);
    setDeleteDialogOpen(true);
  };

  const handleEditSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch(`http://localhost:5000/api/skills/${editSkill._id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
        },
        body: JSON.stringify({
          ...editForm,
          tags: editForm.tags.split(',').map(tag => tag.trim()).filter(Boolean),
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to update skill');
      }

      await fetchUserSkills();
      setEditDialogOpen(false);
      setError('');
    } catch (error) {
      console.error('Error updating skill:', error);
      setError('Failed to update skill');
    }
  };

  const handleDeleteConfirm = async () => {
    try {
      const response = await fetch(`http://localhost:5000/api/skills/${skillToDelete._id}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
        },
      });

      if (!response.ok) {
        throw new Error('Failed to delete skill');
      }

      await fetchUserSkills();
      setDeleteDialogOpen(false);
      setError('');
    } catch (error) {
      console.error('Error deleting skill:', error);
      setError('Failed to delete skill');
    }
  };

  const renderSkillsGrid = (skills) => (
    <Grid container spacing={3}>
      {skills.map((skill) => (
        <Grid item xs={12} sm={6} md={4} key={skill._id}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                {skill.name}
              </Typography>
              <Typography variant="body2" color="text.secondary" paragraph>
                {skill.description || 'No description available'}
              </Typography>
              <Box sx={{ mb: 2 }}>
                <Chip
                  label={skill.proficiencyLevel}
                  size="small"
                  color="primary"
                  sx={{ mr: 1 }}
                />
                {skill.tags?.map((tag) => (
                  <Chip
                    key={tag}
                    label={tag}
                    size="small"
                    variant="outlined"
                    sx={{ mr: 1 }}
                  />
                ))}
              </Box>
            </CardContent>
            <CardActions>
              <IconButton onClick={() => handleEditClick(skill)}>
                <EditIcon />
              </IconButton>
              <IconButton onClick={() => handleDeleteClick(skill)}>
                <DeleteIcon />
              </IconButton>
            </CardActions>
          </Card>
        </Grid>
      ))}
    </Grid>
  );

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Typography variant="h4" gutterBottom>
        My Skills
      </Typography>

      {error && (
        <Typography color="error" sx={{ mb: 2 }}>
          {error}
        </Typography>
      )}

      <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 3 }}>
        <Tabs
          value={selectedTab}
          onChange={(e, newValue) => setSelectedTab(newValue)}
        >
          <Tab label="Learning" />
          <Tab label="Teaching" />
        </Tabs>
      </Box>

      {selectedTab === 0 && renderSkillsGrid(userSkills.learning)}
      {selectedTab === 1 && renderSkillsGrid(userSkills.teaching)}

      {/* Edit Dialog */}
      <Dialog open={editDialogOpen} onClose={() => setEditDialogOpen(false)}>
        <DialogTitle>Edit Skill</DialogTitle>
        <DialogContent>
          <Box component="form" onSubmit={handleEditSubmit} sx={{ mt: 2 }}>
            <TextField
              fullWidth
              label="Name"
              value={editForm.name}
              onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
              margin="normal"
              required
            />
            <TextField
              fullWidth
              label="Description"
              value={editForm.description}
              onChange={(e) => setEditForm({ ...editForm, description: e.target.value })}
              margin="normal"
              multiline
              rows={3}
            />
            <FormControl fullWidth margin="normal">
              <InputLabel>Proficiency Level</InputLabel>
              <Select
                value={editForm.proficiencyLevel}
                onChange={(e) => setEditForm({ ...editForm, proficiencyLevel: e.target.value })}
                label="Proficiency Level"
              >
                <MenuItem value="beginner">Beginner</MenuItem>
                <MenuItem value="intermediate">Intermediate</MenuItem>
                <MenuItem value="advanced">Advanced</MenuItem>
                <MenuItem value="expert">Expert</MenuItem>
              </Select>
            </FormControl>
            <TextField
              fullWidth
              label="Tags (comma-separated)"
              value={editForm.tags}
              onChange={(e) => setEditForm({ ...editForm, tags: e.target.value })}
              margin="normal"
              helperText="Enter tags separated by commas"
            />
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setEditDialogOpen(false)}>Cancel</Button>
          <Button onClick={handleEditSubmit} variant="contained">
            Save Changes
          </Button>
        </DialogActions>
      </Dialog>

      {/* Delete Dialog */}
      <Dialog open={deleteDialogOpen} onClose={() => setDeleteDialogOpen(false)}>
        <DialogTitle>Delete Skill</DialogTitle>
        <DialogContent>
          <Typography>
            Are you sure you want to delete {skillToDelete?.name}? This action cannot be undone.
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteDialogOpen(false)}>Cancel</Button>
          <Button onClick={handleDeleteConfirm} color="error" variant="contained">
            Delete
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
}

export default UserSkills;
