import React from 'react';
import {
  Card,
  CardContent,
  Typography,
  Box,
  Chip,
  Button,
  IconButton,
  Avatar,
  Rating,
  Stack,
  useTheme,
} from '@mui/material';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import HandshakeIcon from '@mui/icons-material/Handshake';
import SchoolIcon from '@mui/icons-material/School';
import TeachIcon from '@mui/icons-material/LocalLibrary';

const SkillCard = ({ skill, onEdit, onDelete, onMatch, showMatchButton }) => {
  const theme = useTheme();

  return (
    <Card
      sx={{
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        position: 'relative',
        transition: 'transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out',
        '&:hover': {
          transform: 'translateY(-4px)',
          boxShadow: theme.shadows[4],
        },
      }}
    >
      <CardContent>
        {/* Header */}
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            {skill.skillType === 'learning' ? (
              <SchoolIcon color="primary" />
            ) : (
              <TeachIcon color="secondary" />
            )}
            <Typography variant="h6" component="div">
              {skill.skillName}
            </Typography>
          </Box>
          <Chip
            label={skill.skillType === 'learning' ? 'Learning' : 'Teaching'}
            color={skill.skillType === 'learning' ? 'primary' : 'secondary'}
            size="small"
          />
        </Box>

        {/* Description */}
        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
          {skill.description}
        </Typography>

        {/* Tags */}
        <Box sx={{ mb: 2 }}>
          <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap>
            {skill.tags.map((tag) => (
              <Chip
                key={tag}
                label={tag}
                size="small"
                sx={{
                  bgcolor: 'background.default',
                  '&:hover': { bgcolor: 'background.default' },
                }}
              />
            ))}
          </Stack>
        </Box>

        {/* User Info (if available) */}
        {skill.createdBy && (
          <Box sx={{ mb: 2 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <Avatar
                src={skill.createdBy.profileImage}
                sx={{ width: 32, height: 32 }}
              >
                {skill.createdBy.name[0]}
              </Avatar>
              <Box>
                <Typography variant="subtitle2">
                  {skill.createdBy.name}
                </Typography>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                  <Rating
                    value={skill.createdBy.rating}
                    precision={0.1}
                    size="small"
                    readOnly
                  />
                  <Typography variant="caption" color="text.secondary">
                    ({skill.createdBy.rating})
                  </Typography>
                </Box>
              </Box>
            </Box>
          </Box>
        )}

        {/* Availability */}
        <Box>
          <Typography variant="subtitle2" color="text.secondary" gutterBottom>
            Available
          </Typography>
          <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap sx={{ mb: 1 }}>
            {skill.availability.weekdays.map((day) => (
              <Chip
                key={day}
                label={day.slice(0, 3)}
                size="small"
                sx={{
                  bgcolor: 'background.default',
                  '&:hover': { bgcolor: 'background.default' },
                }}
              />
            ))}
          </Stack>
          <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap>
            {skill.availability.timeSlots.map((slot, index) => (
              <Chip
                key={index}
                label={`${slot.startTime} - ${slot.endTime}`}
                size="small"
                sx={{
                  bgcolor: 'background.default',
                  '&:hover': { bgcolor: 'background.default' },
                }}
              />
            ))}
          </Stack>
        </Box>

        {/* Actions */}
        <Box sx={{ mt: 2, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          {(onEdit || onDelete) && (
            <Box>
              {onEdit && (
                <IconButton
                  size="small"
                  onClick={() => onEdit(skill)}
                  sx={{ mr: 1 }}
                >
                  <EditIcon fontSize="small" />
                </IconButton>
              )}
              {onDelete && (
                <IconButton
                  size="small"
                  onClick={() => onDelete(skill)}
                  color="error"
                >
                  <DeleteIcon fontSize="small" />
                </IconButton>
              )}
            </Box>
          )}
          {showMatchButton && onMatch && (
            <Button
              variant="contained"
              startIcon={<HandshakeIcon />}
              onClick={() => onMatch(skill)}
              sx={{
                ml: 'auto',
                borderRadius: 2,
                textTransform: 'none',
              }}
            >
              Request Match
            </Button>
          )}
        </Box>
      </CardContent>
    </Card>
  );
};

export default SkillCard;
