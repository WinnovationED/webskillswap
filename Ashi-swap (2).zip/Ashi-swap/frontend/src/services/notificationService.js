import io from 'socket.io-client';

class NotificationService {
  constructor() {
    this.socket = null;
    this.callbacks = {
      onNewMatch: () => {},
      onMatchUpdate: () => {},
      onMatchRequest: () => {},
    };
  }

  connect(userId) {
    this.socket = io('http://localhost:5000', {
      auth: {
        token: localStorage.getItem('token')
      }
    });

    this.socket.on('connect', () => {
      console.log('Connected to notification service');
      this.socket.emit('join', { userId });
    });

    this.socket.on('new_match', (data) => {
      this.callbacks.onNewMatch(data);
    });

    this.socket.on('match_update', (data) => {
      this.callbacks.onMatchUpdate(data);
    });

    this.socket.on('match_request', (data) => {
      this.callbacks.onMatchRequest(data);
    });

    this.socket.on('disconnect', () => {
      console.log('Disconnected from notification service');
    });
  }

  disconnect() {
    if (this.socket) {
      this.socket.disconnect();
      this.socket = null;
    }
  }

  onNewMatch(callback) {
    this.callbacks.onNewMatch = callback;
  }

  onMatchUpdate(callback) {
    this.callbacks.onMatchUpdate = callback;
  }

  onMatchRequest(callback) {
    this.callbacks.onMatchRequest = callback;
  }
}

export default new NotificationService();
