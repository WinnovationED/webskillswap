const mongoose = require('mongoose');

const sessionSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true
  },
  skill: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Skill',
    required: true
  },
  teacher: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  participants: [{
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    status: {
      type: String,
      enum: ['pending', 'accepted', 'declined'],
      default: 'pending'
    },
    joinedAt: {
      type: Date,
      default: Date.now
    }
  }],
  maxParticipants: {
    type: Number,
    required: true,
    default: 5
  },
  schedule: {
    startTime: {
      type: Date,
      required: true
    },
    endTime: {
      type: Date,
      required: true
    },
    timeZone: {
      type: String,
      default: 'UTC'
    },
    recurring: {
      type: Boolean,
      default: false
    },
    frequency: {
      type: String,
      enum: ['once', 'daily', 'weekly', 'monthly'],
      default: 'once'
    }
  },
  description: {
    type: String,
    required: true
  },
  level: {
    type: String,
    enum: ['Beginner', 'Intermediate', 'Expert'],
    required: true
  },
  status: {
    type: String,
    enum: ['scheduled', 'ongoing', 'completed', 'cancelled'],
    default: 'scheduled'
  },
  meetingLink: {
    platform: {
      type: String,
      enum: ['zoom', 'google-meet', 'skype', 'custom'],
      required: true
    },
    url: {
      type: String,
      required: true
    },
    password: String
  },
  chat: [{
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    message: {
      type: String,
      required: true
    },
    timestamp: {
      type: Date,
      default: Date.now
    },
    type: {
      type: String,
      enum: ['text', 'file', 'system'],
      default: 'text'
    }
  }],
  materials: [{
    title: String,
    type: {
      type: String,
      enum: ['document', 'video', 'link', 'other']
    },
    url: String,
    uploadedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    uploadedAt: {
      type: Date,
      default: Date.now
    }
  }],
  feedback: [{
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    rating: {
      type: Number,
      required: true,
      min: 1,
      max: 5
    },
    comment: String,
    createdAt: {
      type: Date,
      default: Date.now
    }
  }],
  tags: [String],
  isPrivate: {
    type: Boolean,
    default: false
  },
  inviteCode: {
    type: String,
    unique: true,
    sparse: true
  }
}, {
  timestamps: true
});

// Create indexes
sessionSchema.index({ skill: 1, status: 1 });
sessionSchema.index({ teacher: 1, status: 1 });
sessionSchema.index({ 'schedule.startTime': 1 });
sessionSchema.index({ tags: 1 });

// Virtual for participant count
sessionSchema.virtual('participantCount').get(function() {
  return this.participants.filter(p => p.status === 'accepted').length;
});

// Virtual for session duration in minutes
sessionSchema.virtual('duration').get(function() {
  return Math.round((this.schedule.endTime - this.schedule.startTime) / (1000 * 60));
});

// Check if session is full
sessionSchema.methods.isFull = function() {
  const acceptedParticipants = this.participants.filter(p => p.status === 'accepted').length;
  return acceptedParticipants >= this.maxParticipants;
};

// Check if user can join
sessionSchema.methods.canJoin = function(userId) {
  if (this.status !== 'scheduled') return false;
  if (this.isFull()) return false;
  if (this.teacher.toString() === userId.toString()) return false;
  
  const existingParticipant = this.participants.find(p => 
    p.user.toString() === userId.toString() && 
    ['accepted', 'pending'].includes(p.status)
  );
  
  return !existingParticipant;
};

module.exports = mongoose.model('Session', sessionSchema);
