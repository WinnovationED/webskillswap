const mongoose = require('mongoose');

const chatRoomSchema = new mongoose.Schema({
  type: {
    type: String,
    enum: ['direct', 'group', 'session'],
    required: true
  },
  name: {
    type: String,
    required: function() {
      return this.type === 'group' || this.type === 'session';
    }
  },
  participants: [{
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true
    },
    role: {
      type: String,
      enum: ['admin', 'member'],
      default: 'member'
    },
    lastRead: {
      type: Date,
      default: Date.now
    }
  }],
  messages: [{
    sender: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true
    },
    content: {
      type: String,
      required: true
    },
    messageType: {
      type: String,
      enum: ['text', 'image', 'file', 'system'],
      default: 'text'
    },
    metadata: {
      fileName: String,
      fileSize: Number,
      fileType: String,
      imageUrl: String,
      thumbnailUrl: String
    },
    readBy: [{
      user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
      },
      readAt: {
        type: Date,
        default: Date.now
      }
    }],
    createdAt: {
      type: Date,
      default: Date.now
    }
  }],
  lastMessage: {
    content: String,
    sender: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    messageType: {
      type: String,
      enum: ['text', 'image', 'file', 'system'],
      default: 'text'
    },
    createdAt: {
      type: Date
    }
  },
  relatedSession: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Session',
    required: function() {
      return this.type === 'session';
    }
  },
  isActive: {
    type: Boolean,
    default: true
  },
  metadata: {
    icon: String,
    description: String,
    customData: mongoose.Schema.Types.Mixed
  }
}, {
  timestamps: true
});

// Indexes for better query performance
chatRoomSchema.index({ 'participants.user': 1 });
chatRoomSchema.index({ type: 1, isActive: 1 });
chatRoomSchema.index({ relatedSession: 1 }, { sparse: true });
chatRoomSchema.index({ 'messages.createdAt': -1 });

// Virtual for unread count
chatRoomSchema.methods.getUnreadCount = function(userId) {
  const participant = this.participants.find(p => 
    p.user.toString() === userId.toString()
  );
  
  if (!participant) return 0;
  
  return this.messages.filter(msg => 
    msg.createdAt > participant.lastRead &&
    msg.sender.toString() !== userId.toString()
  ).length;
};

// Method to add message
chatRoomSchema.methods.addMessage = async function(senderId, content, messageType = 'text', metadata = {}) {
  const message = {
    sender: senderId,
    content,
    messageType,
    metadata,
    readBy: [{ user: senderId }]
  };

  this.messages.push(message);
  this.lastMessage = {
    content,
    sender: senderId,
    messageType,
    createdAt: new Date()
  };

  await this.save();
  return message;
};

// Method to mark messages as read
chatRoomSchema.methods.markAsRead = async function(userId) {
  const participant = this.participants.find(p => 
    p.user.toString() === userId.toString()
  );
  
  if (participant) {
    participant.lastRead = new Date();
    await this.save();
  }
};

module.exports = mongoose.model('ChatRoom', chatRoomSchema);
