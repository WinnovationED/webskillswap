const Skill = require('../models/Skill');
const Match = require('../models/Match');

class MatchingService {
  static async findPotentialMatches(userId) {
    try {
      // Get user's learning skills
      const learningSkills = await Skill.find({
        createdBy: userId,
        skillType: 'learning'
      });

      // Find potential matches for each learning skill
      const matches = await Promise.all(
        learningSkills.map(async (learningSkill) => {
          // Find users teaching this skill
          const teachingSkills = await Skill.find({
            skillName: { $regex: new RegExp(learningSkill.skillName, 'i') },
            skillType: 'teaching',
            createdBy: { $ne: userId }
          })
          .populate('createdBy', 'name email profileImage')
          .populate('ratings');

          // Score and sort matches based on multiple criteria
          const scoredMatches = teachingSkills.map(teachingSkill => {
            let score = 0;

            // Base match score
            score += 1;

            // Availability match score (up to 3 points)
            const commonDays = learningSkill.availability.weekdays.filter(day => 
              teachingSkill.availability.weekdays.includes(day)
            ).length;
            score += (commonDays / 7) * 3;

            // Rating score (up to 2 points)
            if (teachingSkill.averageRating) {
              score += (teachingSkill.averageRating / 5) * 2;
            }

            // Common tags score (up to 2 points)
            const commonTags = learningSkill.tags.filter(tag => 
              teachingSkill.tags.includes(tag)
            ).length;
            const maxTags = Math.max(learningSkill.tags.length, teachingSkill.tags.length);
            if (maxTags > 0) {
              score += (commonTags / maxTags) * 2;
            }

            return {
              learningSkill,
              teachingSkill,
              teacher: teachingSkill.createdBy,
              score,
              commonDays,
              commonTags
            };
          });

          // Sort by score and return top matches
          return scoredMatches.sort((a, b) => b.score - a.score);
        })
      );

      // Flatten and sort all matches
      const allMatches = matches
        .flat()
        .sort((a, b) => b.score - a.score);

      return allMatches;
    } catch (error) {
      throw new Error('Error finding potential matches: ' + error.message);
    }
  }

  static async createMatchRequest(userId, teacherId, skillId) {
    try {
      // Check if a match request already exists
      const existingMatch = await Match.findOne({
        user1: userId,
        user2: teacherId,
        skillExchanged: skillId,
        status: { $in: ['pending', 'accepted'] }
      });

      if (existingMatch) {
        throw new Error('A match request already exists for this skill');
      }

      // Create new match request
      const match = new Match({
        user1: userId,
        user2: teacherId,
        skillExchanged: skillId,
        status: 'pending'
      });

      await match.save();
      return match;
    } catch (error) {
      throw new Error('Error creating match request: ' + error.message);
    }
  }

  static async getMatchSuggestions(userId) {
    try {
      // Get potential matches
      const potentialMatches = await this.findPotentialMatches(userId);

      // Get existing matches to filter out
      const existingMatches = await Match.find({
        $or: [
          { user1: userId },
          { user2: userId }
        ],
        status: { $in: ['pending', 'accepted'] }
      });

      // Filter out existing matches
      const filteredMatches = potentialMatches.filter(match => {
        return !existingMatches.some(existing => 
          existing.skillExchanged.toString() === match.teachingSkill._id.toString() &&
          (existing.user1.toString() === userId && existing.user2.toString() === match.teacher._id ||
           existing.user2.toString() === userId && existing.user1.toString() === match.teacher._id)
        );
      });

      return filteredMatches;
    } catch (error) {
      throw new Error('Error getting match suggestions: ' + error.message);
    }
  }
}

module.exports = MatchingService;
