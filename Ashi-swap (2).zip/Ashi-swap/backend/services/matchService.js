const User = require('../models/User');
const Skill = require('../models/Skill');
const Match = require('../models/Match');

class MatchService {
  static io;

  static initialize(socketIo) {
    this.io = socketIo;
  }

  static async findPotentialMatches(userId) {
    try {
      // Get user's learning skills
      const user = await User.findById(userId).populate('skills');
      const learningSkills = user.skills.filter(skill => skill.type === 'learning');

      // Find users teaching those skills
      const potentialMatches = [];
      for (const learningSkill of learningSkills) {
        const teachingUsers = await User.find({
          _id: { $ne: userId },
          skills: {
            $elemMatch: {
              skillName: learningSkill.skillName,
              type: 'teaching'
            }
          }
        }).populate('skills');

        // Calculate match scores
        for (const teacher of teachingUsers) {
          const teachingSkill = teacher.skills.find(
            s => s.skillName === learningSkill.skillName && s.type === 'teaching'
          );

          if (teachingSkill) {
            const score = await this.calculateMatchScore(learningSkill, teachingSkill, user, teacher);
            const commonDays = this.findCommonAvailability(learningSkill, teachingSkill);
            const commonTags = this.findCommonTags(learningSkill, teachingSkill);

            potentialMatches.push({
              teacher,
              learningSkill,
              teachingSkill,
              score,
              commonDays,
              commonTags: commonTags.length
            });
          }
        }
      }

      // Sort matches by score
      return potentialMatches.sort((a, b) => b.score - a.score);
    } catch (error) {
      console.error('Error finding potential matches:', error);
      throw error;
    }
  }

  static async calculateMatchScore(learningSkill, teachingSkill, student, teacher) {
    let score = 0;

    // Base match score for skill name match
    score += 1;

    // Add score for common availability
    const commonDays = this.findCommonAvailability(learningSkill, teachingSkill);
    score += commonDays.length * 0.2;

    // Add score for teacher rating
    if (teachingSkill.ratings && teachingSkill.ratings.length > 0) {
      const avgRating = teachingSkill.ratings.reduce((a, b) => a + b, 0) / teachingSkill.ratings.length;
      score += avgRating * 0.3;
    }

    // Add score for common interests/tags
    const commonTags = this.findCommonTags(learningSkill, teachingSkill);
    score += commonTags.length * 0.1;

    return score;
  }

  static findCommonAvailability(skill1, skill2) {
    return skill1.availability.weekdays.filter(day => 
      skill2.availability.weekdays.includes(day)
    );
  }

  static findCommonTags(skill1, skill2) {
    return skill1.tags.filter(tag => skill2.tags.includes(tag));
  }

  static async createMatch(studentId, teacherId, skillId) {
    try {
      // Check if match already exists
      const existingMatch = await Match.findOne({
        $or: [
          { user1: studentId, user2: teacherId, skillExchanged: skillId },
          { user1: teacherId, user2: studentId, skillExchanged: skillId }
        ]
      });

      if (existingMatch) {
        throw new Error('Match already exists');
      }

      // Create new match
      const match = new Match({
        user1: studentId,
        user2: teacherId,
        skillExchanged: skillId,
        status: 'pending'
      });

      await match.save();

      // Populate match details for notification
      const populatedMatch = await Match.findById(match._id)
        .populate('user1', 'name')
        .populate('user2', 'name')
        .populate('skillExchanged', 'skillName');

      // Send real-time notification
      if (this.io) {
        this.io.to(teacherId.toString()).emit('match_request', {
          matchId: match._id,
          studentName: populatedMatch.user1.name,
          skillName: populatedMatch.skillExchanged.skillName
        });
      }

      return match;
    } catch (error) {
      console.error('Error creating match:', error);
      throw error;
    }
  }

  static async updateMatchStatus(matchId, status) {
    try {
      const match = await Match.findByIdAndUpdate(
        matchId,
        { status },
        { new: true }
      ).populate('user1 user2 skillExchanged');

      // Send real-time notification
      if (this.io) {
        const notifyUserId = match.user1._id.toString();
        this.io.to(notifyUserId).emit('match_update', {
          matchId: match._id,
          status,
          userName: match.user2.name,
          skillName: match.skillExchanged.skillName
        });
      }

      return match;
    } catch (error) {
      console.error('Error updating match status:', error);
      throw error;
    }
  }

  static async getUserMatches(userId) {
    try {
      const matches = await Match.find({
        $or: [{ user1: userId }, { user2: userId }]
      })
        .populate('user1 user2 skillExchanged')
        .sort('-createdAt');
      return matches;
    } catch (error) {
      console.error('Error getting user matches:', error);
      throw error;
    }
  }
}

module.exports = MatchService;
