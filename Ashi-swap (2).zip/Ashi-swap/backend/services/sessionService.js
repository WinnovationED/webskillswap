const Session = require('../models/Session');
const User = require('../models/User');
const ChatRoom = require('../models/ChatRoom');
const { v4: uuidv4 } = require('uuid');

class SessionService {
  static io;

  static initialize(socketIo) {
    this.io = socketIo;
  }

  static async createSession(teacherId, sessionData) {
    try {
      // Create the session
      const session = new Session({
        ...sessionData,
        teacher: teacherId,
        inviteCode: uuidv4().substring(0, 8)
      });

      // Create a chat room for the session
      const chatRoom = new ChatRoom({
        type: 'session',
        name: sessionData.title,
        participants: [{
          user: teacherId,
          role: 'admin'
        }],
        relatedSession: session._id
      });

      // Generate meeting link
      session.meetingLink = {
        platform: 'custom',
        url: `https://meet.skillswap.com/${session.inviteCode}`,
        password: uuidv4().substring(0, 6)
      };

      await Promise.all([session.save(), chatRoom.save()]);

      // Notify potential participants
      await this.notifyPotentialParticipants(session);

      return { session, chatRoom };
    } catch (error) {
      console.error('Error creating session:', error);
      throw error;
    }
  }

  static async notifyPotentialParticipants(session) {
    try {
      // Find users who want to learn this skill
      const potentialLearners = await User.find({
        'learningSkills.skill': session.skill,
        'learningSkills.proficiencyLevel': session.level,
        _id: { $ne: session.teacher }
      });

      // Send notifications
      const notifications = potentialLearners.map(user => ({
        userId: user._id,
        notification: {
          type: 'session',
          title: 'New Learning Session Available',
          message: `A new session for ${session.title} has been created. Join now!`,
          relatedId: session._id
        }
      }));

      if (this.io) {
        notifications.forEach(({ userId, notification }) => {
          this.io.to(userId.toString()).emit('new_session', {
            sessionId: session._id,
            ...notification
          });
        });
      }

      // Save notifications to users
      await Promise.all(
        notifications.map(({ userId, notification }) =>
          User.findByIdAndUpdate(userId, {
            $push: { notifications: notification }
          })
        )
      );
    } catch (error) {
      console.error('Error notifying potential participants:', error);
    }
  }

  static async joinSession(sessionId, userId) {
    try {
      const session = await Session.findById(sessionId);
      if (!session) throw new Error('Session not found');

      if (!session.canJoin(userId)) {
        throw new Error('Cannot join this session');
      }

      // Add user to session participants
      session.participants.push({
        user: userId,
        status: 'pending'
      });

      // Add user to session chat room
      const chatRoom = await ChatRoom.findOne({ relatedSession: sessionId });
      if (chatRoom) {
        chatRoom.participants.push({
          user: userId,
          role: 'member'
        });
        await chatRoom.save();
      }

      await session.save();

      // Notify teacher
      if (this.io) {
        this.io.to(session.teacher.toString()).emit('session_join_request', {
          sessionId: session._id,
          userId,
          title: session.title
        });
      }

      return session;
    } catch (error) {
      console.error('Error joining session:', error);
      throw error;
    }
  }

  static async updateParticipantStatus(sessionId, userId, status) {
    try {
      const session = await Session.findById(sessionId);
      if (!session) throw new Error('Session not found');

      const participant = session.participants.find(
        p => p.user.toString() === userId.toString()
      );

      if (!participant) throw new Error('Participant not found');

      participant.status = status;
      await session.save();

      // Notify participant
      if (this.io) {
        this.io.to(userId.toString()).emit('session_status_update', {
          sessionId: session._id,
          status,
          title: session.title
        });
      }

      return session;
    } catch (error) {
      console.error('Error updating participant status:', error);
      throw error;
    }
  }

  static async addSessionMaterial(sessionId, material) {
    try {
      const session = await Session.findById(sessionId);
      if (!session) throw new Error('Session not found');

      session.materials.push(material);
      await session.save();

      // Notify participants
      if (this.io) {
        session.participants.forEach(participant => {
          if (participant.status === 'accepted') {
            this.io.to(participant.user.toString()).emit('new_material', {
              sessionId: session._id,
              material
            });
          }
        });
      }

      return session;
    } catch (error) {
      console.error('Error adding session material:', error);
      throw error;
    }
  }

  static async addSessionFeedback(sessionId, userId, feedback) {
    try {
      const session = await Session.findById(sessionId);
      if (!session) throw new Error('Session not found');

      // Check if user was a participant
      const participant = session.participants.find(
        p => p.user.toString() === userId.toString() && p.status === 'accepted'
      );

      if (!participant) throw new Error('Only participants can provide feedback');

      // Add feedback
      session.feedback.push({
        user: userId,
        ...feedback
      });

      // Update teacher's rating
      const teacher = await User.findById(session.teacher);
      const teachingSkill = teacher.teachingSkills.find(
        skill => skill.skill.toString() === session.skill.toString()
      );

      if (teachingSkill) {
        const totalRating = teachingSkill.rating * teachingSkill.reviewCount + feedback.rating;
        teachingSkill.reviewCount += 1;
        teachingSkill.rating = totalRating / teachingSkill.reviewCount;
        await teacher.save();
      }

      await session.save();

      // Notify teacher
      if (this.io) {
        this.io.to(session.teacher.toString()).emit('new_feedback', {
          sessionId: session._id,
          rating: feedback.rating
        });
      }

      return session;
    } catch (error) {
      console.error('Error adding session feedback:', error);
      throw error;
    }
  }

  static async getUpcomingSessions(userId) {
    try {
      return await Session.find({
        $or: [
          { teacher: userId },
          { 'participants.user': userId, 'participants.status': 'accepted' }
        ],
        status: 'scheduled',
        'schedule.startTime': { $gt: new Date() }
      })
        .populate('skill')
        .populate('teacher', 'name email profileImage')
        .populate('participants.user', 'name email profileImage')
        .sort('schedule.startTime');
    } catch (error) {
      console.error('Error getting upcoming sessions:', error);
      throw error;
    }
  }

  static async searchSessions(filters) {
    try {
      const query = {
        status: 'scheduled',
        'schedule.startTime': { $gt: new Date() }
      };

      if (filters.skillId) query.skill = filters.skillId;
      if (filters.level) query.level = filters.level;
      if (filters.tags) query.tags = { $in: filters.tags };

      return await Session.find(query)
        .populate('skill')
        .populate('teacher', 'name email profileImage teachingSkills')
        .sort('schedule.startTime');
    } catch (error) {
      console.error('Error searching sessions:', error);
      throw error;
    }
  }
}

module.exports = SessionService;
