const ChatRoom = require('../models/ChatRoom');
const Message = require('../models/Message');
const NotificationService = require('./notificationService');

class ChatService {
  static io;

  static initialize(socketIo) {
    this.io = socketIo;
  }

  static async createChatRoom(data) {
    try {
      const chatRoom = new ChatRoom({
        type: data.type,
        name: data.name,
        participants: data.participants.map(userId => ({
          user: userId,
          role: data.creatorId === userId ? 'admin' : 'member'
        }))
      });

      await chatRoom.save();
      return chatRoom;
    } catch (error) {
      console.error('Error creating chat room:', error);
      throw error;
    }
  }

  static async getChatRooms(userId) {
    try {
      const chatRooms = await ChatRoom.find({
        'participants.user': userId,
        isActive: true
      })
      .populate('participants.user', 'name email profileImage')
      .sort('-updatedAt');

      return chatRooms;
    } catch (error) {
      console.error('Error getting chat rooms:', error);
      throw error;
    }
  }

  static async getChatMessages(chatRoomId, userId, query = {}) {
    try {
      const chatRoom = await ChatRoom.findById(chatRoomId);
      if (!chatRoom) {
        throw new Error('Chat room not found');
      }

      const participant = chatRoom.participants.find(p => 
        p.user.toString() === userId.toString()
      );
      if (!participant) {
        throw new Error('Not authorized to view this chat room');
      }

      let filter = { chatRoom: chatRoomId };
      const messages = await Message.find(filter)
        .populate('sender', 'name email profileImage')
        .populate('replyTo')
        .sort('-createdAt')
        .limit(query.limit || 50)
        .skip(query.skip || 0);

      return messages;
    } catch (error) {
      console.error('Error getting chat messages:', error);
      throw error;
    }
  }

  static async sendMessage(chatRoomId, senderId, data) {
    try {
      const chatRoom = await ChatRoom.findById(chatRoomId);
      if (!chatRoom) {
        throw new Error('Chat room not found');
      }

      const participant = chatRoom.participants.find(p => 
        p.user.toString() === senderId.toString()
      );
      if (!participant) {
        throw new Error('Not authorized to send messages in this chat room');
      }

      const message = new Message({
        chatRoom: chatRoomId,
        sender: senderId,
        content: data.content,
        messageType: data.messageType || 'text',
        metadata: data.metadata,
        replyTo: data.replyTo
      });

      await message.save();

      // Update chat room's last message
      chatRoom.lastMessage = {
        sender: senderId,
        content: data.content,
        messageType: data.messageType || 'text',
        sentAt: new Date()
      };
      await chatRoom.save();

      // Send real-time message to all participants
      if (this.io) {
        chatRoom.participants.forEach(participant => {
          if (participant.user.toString() !== senderId.toString()) {
            this.io.to(participant.user.toString()).emit('new_message', {
              chatRoomId,
              message: {
                ...message.toObject(),
                sender: { _id: senderId }
              }
            });

            // Create notification for unread message
            NotificationService.createNotification({
              userId: participant.user,
              type: 'message_received',
              title: 'New Message',
              message: `You have a new message in ${chatRoom.name || 'chat'}`,
              relatedId: message._id,
              metadata: {
                chatRoomId,
                senderId
              }
            });
          }
        });
      }

      return message;
    } catch (error) {
      console.error('Error sending message:', error);
      throw error;
    }
  }

  static async markMessagesAsRead(chatRoomId, userId) {
    try {
      const chatRoom = await ChatRoom.findById(chatRoomId);
      if (!chatRoom) {
        throw new Error('Chat room not found');
      }

      const participant = chatRoom.participants.find(p => 
        p.user.toString() === userId.toString()
      );
      if (!participant) {
        throw new Error('Not a participant of this chat room');
      }

      // Update participant's last read timestamp
      participant.lastRead = new Date();
      await chatRoom.save();

      // Mark messages as read
      await Message.updateMany(
        {
          chatRoom: chatRoomId,
          'readBy.user': { $ne: userId }
        },
        {
          $push: {
            readBy: {
              user: userId,
              readAt: new Date()
            }
          }
        }
      );

      return true;
    } catch (error) {
      console.error('Error marking messages as read:', error);
      throw error;
    }
  }

  static async getUnreadCount(userId) {
    try {
      const chatRooms = await ChatRoom.find({
        'participants.user': userId,
        isActive: true
      });

      const unreadCounts = await Promise.all(
        chatRooms.map(async chatRoom => {
          const participant = chatRoom.participants.find(p => 
            p.user.toString() === userId.toString()
          );

          const unreadCount = await Message.countDocuments({
            chatRoom: chatRoom._id,
            createdAt: { $gt: participant.lastRead },
            sender: { $ne: userId }
          });

          return {
            chatRoomId: chatRoom._id,
            unreadCount
          };
        })
      );

      return unreadCounts;
    } catch (error) {
      console.error('Error getting unread count:', error);
      throw error;
    }
  }
}

module.exports = ChatService;
