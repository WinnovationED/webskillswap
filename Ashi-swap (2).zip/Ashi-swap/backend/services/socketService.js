const jwt = require('jsonwebtoken');
const User = require('../models/User');

class SocketService {
  constructor(io) {
    this.io = io;
    this.userSockets = new Map(); // userId -> socketId
    this.setupSocketAuth();
    this.setupEventHandlers();
  }

  setupSocketAuth() {
    this.io.use(async (socket, next) => {
      try {
        const token = socket.handshake.auth.token;
        if (!token) {
          throw new Error('Authentication error');
        }

        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        const user = await User.findById(decoded._id);
        if (!user) {
          throw new Error('User not found');
        }

        socket.user = user;
        next();
      } catch (error) {
        next(new Error('Authentication error'));
      }
    });
  }

  setupEventHandlers() {
    this.io.on('connection', (socket) => {
      console.log('User connected:', socket.user._id);
      this.userSockets.set(socket.user._id.toString(), socket.id);

      socket.on('join', ({ userId }) => {
        if (socket.user._id.toString() === userId) {
          socket.join(`user:${userId}`);
        }
      });

      socket.on('send_message', async (data) => {
        try {
          const { roomId, content, messageType, metadata } = data;
          const message = {
            chatRoom: roomId,
            sender: socket.user._id,
            content,
            messageType,
            metadata,
            createdAt: new Date()
          };

          // Emit to all users in the room
          this.io.to(`room:${roomId}`).emit('new_message', {
            chatRoomId: roomId,
            message
          });
        } catch (error) {
          console.error('Error sending message:', error);
          socket.emit('error', { message: 'Failed to send message' });
        }
      });

      socket.on('mark_read', async (data) => {
        try {
          const { roomId } = data;
          this.io.to(`room:${roomId}`).emit('message_read', {
            roomId,
            userId: socket.user._id
          });
        } catch (error) {
          console.error('Error marking messages as read:', error);
        }
      });

      socket.on('disconnect', () => {
        console.log('User disconnected:', socket.user._id);
        this.userSockets.delete(socket.user._id.toString());
      });
    });
  }

  // Notify a user about a new match
  notifyNewMatch(userId, teacherId, skillName) {
    const teacherSocket = this.userSockets.get(teacherId.toString());
    if (teacherSocket) {
      this.io.to(teacherSocket).emit('new_match', {
        studentId: userId,
        skillName
      });
    }
  }

  // Notify a user about a match update
  notifyMatchUpdate(userId, matchId, status) {
    const userSocket = this.userSockets.get(userId.toString());
    if (userSocket) {
      this.io.to(userSocket).emit('match_update', {
        matchId,
        status
      });
    }
  }

  // Notify a user about a new match request
  notifyMatchRequest(teacherId, studentId, skillName) {
    const teacherSocket = this.userSockets.get(teacherId.toString());
    if (teacherSocket) {
      this.io.to(teacherSocket).emit('match_request', {
        studentId,
        skillName
      });
    }
  }
}

module.exports = SocketService;
