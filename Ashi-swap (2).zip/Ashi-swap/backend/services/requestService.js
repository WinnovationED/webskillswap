const Request = require('../models/Request');
const User = require('../models/User');
const ChatRoom = require('../models/ChatRoom');
const notificationService = require('./notificationService');

class RequestService {
  static io;

  static initialize(socketIo) {
    this.io = socketIo;
  }

  static async createRequest(fromUserId, data) {
    try {
      // Create chat room for the request
      const chatRoom = new ChatRoom({
        type: data.type === 'group' ? 'group' : 'private',
        participants: [
          { user: fromUserId, role: 'member' },
          { user: data.to, role: 'member' }
        ]
      });

      // Create the request
      const request = new Request({
        from: fromUserId,
        to: data.to,
        skill: data.skillId,
        message: data.message,
        type: data.type || 'individual',
        groupSize: data.groupSize || 1,
        schedule: data.schedule,
        preferences: data.preferences,
        tags: data.tags,
        chatRoom: chatRoom._id,
        participants: [
          { user: fromUserId, status: 'accepted' }
        ]
      });

      await Promise.all([request.save(), chatRoom.save()]);

      // Notify the recipient
      if (this.io) {
        this.io.to(data.to.toString()).emit('new_request', {
          requestId: request._id,
          from: fromUserId,
          skill: data.skillId,
          type: request.type
        });
      }

      return request;
    } catch (error) {
      console.error('Error creating request:', error);
      throw error;
    }
  }

  static async getRequests(userId, filters = {}) {
    try {
      let query = {
        $or: [
          { from: userId },
          { to: userId },
          { 'participants.user': userId }
        ]
      };

      // Apply filters
      if (filters.status) {
        query.status = filters.status;
      }
      if (filters.type) {
        query.type = filters.type;
      }
      if (filters.skill) {
        query.skill = filters.skill;
      }
      if (filters.search) {
        query.$or = [
          { message: { $regex: filters.search, $options: 'i' } },
          { tags: { $regex: filters.search, $options: 'i' } }
        ];
      }

      const requests = await Request.find(query)
        .populate('from', 'name email profileImage')
        .populate('to', 'name email profileImage')
        .populate('skill')
        .populate('participants.user', 'name email profileImage')
        .sort('-createdAt');

      return requests;
    } catch (error) {
      console.error('Error getting requests:', error);
      throw error;
    }
  }

  static async updateRequestStatus(requestId, userId, status) {
    try {
      const request = await Request.findById(requestId)
        .populate('from', 'name email')
        .populate('to', 'name email')
        .populate('skill', 'name');

      if (!request) {
        throw new Error('Request not found');
      }

      if (!request.canModify(userId)) {
        throw new Error('Not authorized to modify this request');
      }

      request.status = status;

      // If accepting a group request, add the user as a participant
      if (status === 'accepted' && request.type === 'group') {
        const participant = request.participants.find(p => 
          p.user.toString() === userId.toString()
        );

        if (!participant && request.participants.length < request.groupSize) {
          request.participants.push({
            user: userId,
            status: 'accepted'
          });
        }
      }

      await request.save();

      // Notify relevant users
      if (this.io) {
        const notification = {
          requestId: request._id,
          status,
          from: request.from.name,
          to: request.to.name,
          skill: request.skill.name
        };

        // Notify the requester
        this.io.to(request.from._id.toString()).emit('request_status_update', notification);

        // Notify other participants in group requests
        if (request.type === 'group') {
          request.participants.forEach(participant => {
            if (participant.user.toString() !== userId.toString()) {
              this.io.to(participant.user.toString()).emit('request_status_update', notification);
            }
          });
        }
      }

      return request;
    } catch (error) {
      console.error('Error updating request status:', error);
      throw error;
    }
  }

  static async joinGroupRequest(requestId, userId) {
    try {
      const request = await Request.findById(requestId);
      
      if (!request) {
        throw new Error('Request not found');
      }

      if (!request.canJoin(userId)) {
        throw new Error('Cannot join this request');
      }

      request.participants.push({
        user: userId,
        status: 'pending'
      });

      await request.save();

      // Notify the request owner
      if (this.io) {
        this.io.to(request.from.toString()).emit('group_join_request', {
          requestId: request._id,
          userId,
          type: request.type
        });
      }

      return request;
    } catch (error) {
      console.error('Error joining group request:', error);
      throw error;
    }
  }

  static async updateParticipantStatus(requestId, participantId, status) {
    try {
      const request = await Request.findById(requestId);
      
      if (!request) {
        throw new Error('Request not found');
      }

      const participant = request.participants.find(p => 
        p.user.toString() === participantId.toString()
      );

      if (!participant) {
        throw new Error('Participant not found');
      }

      participant.status = status;
      await request.save();

      // Notify the participant
      if (this.io) {
        this.io.to(participantId.toString()).emit('participant_status_update', {
          requestId: request._id,
          status,
          type: request.type
        });
      }

      return request;
    } catch (error) {
      console.error('Error updating participant status:', error);
      throw error;
    }
  }

  static async updateSchedule(requestId, userId, schedule) {
    try {
      const request = await Request.findById(requestId);
      
      if (!request) {
        throw new Error('Request not found');
      }

      if (!request.canModify(userId)) {
        throw new Error('Not authorized to modify this request');
      }

      request.schedule = schedule;
      await request.save();

      // Notify participants
      if (this.io) {
        const notification = {
          requestId: request._id,
          schedule,
          type: request.type
        };

        request.participants.forEach(participant => {
          if (participant.status === 'accepted') {
            this.io.to(participant.user.toString()).emit('schedule_update', notification);
          }
        });
      }

      return request;
    } catch (error) {
      console.error('Error updating schedule:', error);
      throw error;
    }
  }

  static async completeRequest(requestId, userId) {
    try {
      const request = await Request.findById(requestId);
      
      if (!request) {
        throw new Error('Request not found');
      }

      if (!request.canModify(userId)) {
        throw new Error('Not authorized to modify this request');
      }

      request.status = 'completed';
      await request.save();

      // Notify participants
      if (this.io) {
        const notification = {
          requestId: request._id,
          type: request.type,
          status: 'completed'
        };

        request.participants.forEach(participant => {
          this.io.to(participant.user.toString()).emit('request_completed', notification);
        });
      }

      return request;
    } catch (error) {
      console.error('Error completing request:', error);
      throw error;
    }
  }
}

module.exports = RequestService;
