const MatchService = require('../services/matchService');
const Match = require('../models/Match');

exports.getSuggestions = async (req, res) => {
  try {
    const userId = req.user._id;
    const matches = await MatchService.findPotentialMatches(userId);
    res.json(matches);
  } catch (error) {
    console.error('Error getting match suggestions:', error);
    res.status(500).json({ error: 'Failed to get match suggestions' });
  }
};

exports.createMatch = async (req, res) => {
  try {
    const { teacherId, skillId } = req.body;
    const studentId = req.user._id;

    const match = await MatchService.createMatch(studentId, teacherId, skillId);
    res.status(201).json(match);
  } catch (error) {
    console.error('Error creating match:', error);
    res.status(500).json({ error: 'Failed to create match' });
  }
};

exports.updateMatchStatus = async (req, res) => {
  try {
    const { matchId } = req.params;
    const { status } = req.body;
    const userId = req.user._id;

    // Verify user is part of the match
    const match = await Match.findById(matchId);
    if (!match) {
      return res.status(404).json({ error: 'Match not found' });
    }

    if (match.user1.toString() !== userId.toString() && 
        match.user2.toString() !== userId.toString()) {
      return res.status(403).json({ error: 'Not authorized to update this match' });
    }

    const updatedMatch = await MatchService.updateMatchStatus(matchId, status);
    res.json(updatedMatch);
  } catch (error) {
    console.error('Error updating match status:', error);
    res.status(500).json({ error: 'Failed to update match status' });
  }
};

exports.getUserMatches = async (req, res) => {
  try {
    const userId = req.user._id;
    const matches = await MatchService.getUserMatches(userId);
    res.json(matches);
  } catch (error) {
    console.error('Error getting user matches:', error);
    res.status(500).json({ error: 'Failed to get user matches' });
  }
};
