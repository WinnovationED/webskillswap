const SessionService = require('../services/sessionService');
const Session = require('../models/Session');
const User = require('../models/User');

exports.createSession = async (req, res) => {
  try {
    const teacherId = req.user._id;
    const { session, chatRoom } = await SessionService.createSession(teacherId, req.body);
    res.status(201).json({ session, chatRoomId: chatRoom._id });
  } catch (error) {
    console.error('Error in createSession:', error);
    res.status(500).json({ error: 'Failed to create session' });
  }
};

exports.getSessions = async (req, res) => {
  try {
    const { type, status, skillId } = req.query;
    let query = {};

    if (type === 'teaching') {
      query.teacher = req.user._id;
    } else if (type === 'learning') {
      query['participants.user'] = req.user._id;
    }

    if (status) query.status = status;
    if (skillId) query.skill = skillId;

    const sessions = await Session.find(query)
      .populate('skill')
      .populate('teacher', 'name email profileImage')
      .populate('participants.user', 'name email profileImage')
      .sort('-schedule.startTime');

    res.json(sessions);
  } catch (error) {
    console.error('Error in getSessions:', error);
    res.status(500).json({ error: 'Failed to get sessions' });
  }
};

exports.getSessionById = async (req, res) => {
  try {
    const session = await Session.findById(req.params.id)
      .populate('skill')
      .populate('teacher', 'name email profileImage teachingSkills')
      .populate('participants.user', 'name email profileImage')
      .populate('materials.uploadedBy', 'name');

    if (!session) {
      return res.status(404).json({ error: 'Session not found' });
    }

    res.json(session);
  } catch (error) {
    console.error('Error in getSessionById:', error);
    res.status(500).json({ error: 'Failed to get session' });
  }
};

exports.joinSession = async (req, res) => {
  try {
    const session = await SessionService.joinSession(req.params.id, req.user._id);
    res.json(session);
  } catch (error) {
    console.error('Error in joinSession:', error);
    res.status(400).json({ error: error.message });
  }
};

exports.updateParticipantStatus = async (req, res) => {
  try {
    const { id, userId } = req.params;
    const { status } = req.body;

    // Verify that the current user is the teacher
    const session = await Session.findById(id);
    if (!session) {
      return res.status(404).json({ error: 'Session not found' });
    }

    if (session.teacher.toString() !== req.user._id.toString()) {
      return res.status(403).json({ error: 'Only the teacher can update participant status' });
    }

    const updatedSession = await SessionService.updateParticipantStatus(id, userId, status);
    res.json(updatedSession);
  } catch (error) {
    console.error('Error in updateParticipantStatus:', error);
    res.status(400).json({ error: error.message });
  }
};

exports.addMaterial = async (req, res) => {
  try {
    const sessionId = req.params.id;
    const material = {
      ...req.body,
      uploadedBy: req.user._id,
      uploadedAt: new Date()
    };

    const session = await SessionService.addSessionMaterial(sessionId, material);
    res.json(session);
  } catch (error) {
    console.error('Error in addMaterial:', error);
    res.status(400).json({ error: error.message });
  }
};

exports.addFeedback = async (req, res) => {
  try {
    const session = await SessionService.addSessionFeedback(
      req.params.id,
      req.user._id,
      req.body
    );
    res.json(session);
  } catch (error) {
    console.error('Error in addFeedback:', error);
    res.status(400).json({ error: error.message });
  }
};

exports.getUpcomingSessions = async (req, res) => {
  try {
    const sessions = await SessionService.getUpcomingSessions(req.user._id);
    res.json(sessions);
  } catch (error) {
    console.error('Error in getUpcomingSessions:', error);
    res.status(500).json({ error: 'Failed to get upcoming sessions' });
  }
};

exports.searchSessions = async (req, res) => {
  try {
    const sessions = await SessionService.searchSessions(req.query);
    res.json(sessions);
  } catch (error) {
    console.error('Error in searchSessions:', error);
    res.status(500).json({ error: 'Failed to search sessions' });
  }
};

exports.cancelSession = async (req, res) => {
  try {
    const session = await Session.findById(req.params.id);
    if (!session) {
      return res.status(404).json({ error: 'Session not found' });
    }

    if (session.teacher.toString() !== req.user._id.toString()) {
      return res.status(403).json({ error: 'Only the teacher can cancel the session' });
    }

    session.status = 'cancelled';
    await session.save();

    // Notify participants
    if (SessionService.io) {
      session.participants.forEach(participant => {
        if (participant.status === 'accepted') {
          SessionService.io.to(participant.user.toString()).emit('session_cancelled', {
            sessionId: session._id,
            title: session.title
          });
        }
      });
    }

    res.json(session);
  } catch (error) {
    console.error('Error in cancelSession:', error);
    res.status(500).json({ error: 'Failed to cancel session' });
  }
};
