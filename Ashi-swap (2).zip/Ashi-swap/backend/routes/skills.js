const express = require('express');
const Skill = require('../models/Skill');
const auth = require('../middleware/auth');
const router = express.Router();

// Create a new skill
router.post('/', auth, async (req, res) => {
  try {
    const skill = new Skill({
      ...req.body,
      createdBy: req.user._id
    });
    await skill.save();
    res.status(201).json(skill);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Get all skills with search, filter, and matching
router.get('/', async (req, res) => {
  try {
    const { search, tags, skillType, weekdays, startTime, endTime, rating, page = 1, limit = 10 } = req.query;
    const query = {};

    if (search) {
      query.$text = { $search: search };
    }

    if (tags) {
      query.tags = { $all: Array.isArray(tags) ? tags : [tags] };
    }

    if (skillType) {
      query.skillType = skillType;
    }

    if (rating) {
      query.averageRating = { $gte: Number(rating) };
    }

    // Filter by availability
    if (weekdays || startTime || endTime) {
      if (weekdays) {
        query['availability.weekdays'] = { 
          $in: Array.isArray(weekdays) ? weekdays : [weekdays] 
        };
      }
      
      if (startTime || endTime) {
        const timeQuery = {};
        if (startTime) timeQuery['$gte'] = startTime;
        if (endTime) timeQuery['$lte'] = endTime;
        query['availability.timeSlots'] = {
          $elemMatch: {
            startTime: timeQuery
          }
        };
      }
    }

    const skills = await Skill.find(query)
      .populate('createdBy', 'name email profileImage')
      .skip((page - 1) * limit)
      .limit(Number(limit))
      .sort({ createdAt: -1 });

    const total = await Skill.countDocuments(query);

    res.json({
      skills,
      totalPages: Math.ceil(total / limit),
      currentPage: page
    });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Get a specific skill
router.get('/:id', async (req, res) => {
  try {
    const skill = await Skill.findById(req.params.id)
      .populate('createdBy', 'name email profileImage')
      .populate('ratings.user', 'name email profileImage');
    
    if (!skill) {
      return res.status(404).json({ error: 'Skill not found' });
    }
    
    res.json(skill);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Update a skill
router.patch('/:id', auth, async (req, res) => {
  try {
    const skill = await Skill.findOne({
      _id: req.params.id,
      createdBy: req.user._id
    });

    if (!skill) {
      return res.status(404).json({ error: 'Skill not found' });
    }

    Object.assign(skill, req.body);
    await skill.save();
    res.json(skill);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Delete a skill
router.delete('/:id', auth, async (req, res) => {
  try {
    const skill = await Skill.findOneAndDelete({
      _id: req.params.id,
      createdBy: req.user._id
    });

    if (!skill) {
      return res.status(404).json({ error: 'Skill not found' });
    }

    res.json({ message: 'Skill deleted successfully' });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Rate a skill
router.post('/:id/rate', auth, async (req, res) => {
  try {
    const { rating } = req.body;
    if (typeof rating !== 'number' || rating < 0 || rating > 5) {
      return res.status(400).json({ error: 'Rating must be a number between 0 and 5' });
    }

    const skill = await Skill.findById(req.params.id);
    if (!skill) {
      return res.status(404).json({ error: 'Skill not found' });
    }

    // Don't allow rating your own skills
    if (skill.createdBy.toString() === req.user._id.toString()) {
      return res.status(400).json({ error: 'You cannot rate your own skills' });
    }

    // Update existing rating or add new one
    const ratingIndex = skill.ratings.findIndex(r => r.user.toString() === req.user._id.toString());
    if (ratingIndex > -1) {
      skill.ratings[ratingIndex].rating = rating;
    } else {
      skill.ratings.push({
        user: req.user._id,
        rating
      });
    }

    await skill.save();
    res.json(skill);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Get user's skills
router.get('/user/:userId', async (req, res) => {
  try {
    const skills = await Skill.find({ createdBy: req.params.userId })
      .populate('createdBy', 'name email profileImage')
      .sort({ createdAt: -1 });
    res.json(skills);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

module.exports = router;
