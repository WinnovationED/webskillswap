const express = require('express');
const router = express.Router();
const Request = require('../models/Request');
const auth = require('../middleware/auth');

// Create a new request
router.post('/', auth, async (req, res) => {
  try {
    const request = new Request({
      from: req.user._id,
      to: req.body.to,
      skill: req.body.skillId,
      message: req.body.message
    });
    await request.save();
    
    // Populate the request with user and skill details
    await request.populate([
      { path: 'from', select: 'name email profileImage' },
      { path: 'to', select: 'name email profileImage' },
      { path: 'skill' }
    ]);
    
    res.status(201).json(request);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Get all requests for a user (both sent and received)
router.get('/', auth, async (req, res) => {
  try {
    const requests = await Request.find({
      $or: [{ from: req.user._id }, { to: req.user._id }]
    })
    .populate('from', 'name email profileImage')
    .populate('to', 'name email profileImage')
    .populate('skill')
    .sort({ createdAt: -1 });
    
    res.json(requests);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Accept or reject a request
router.patch('/:id', auth, async (req, res) => {
  try {
    const request = await Request.findOne({
      _id: req.params.id,
      to: req.user._id
    });

    if (!request) {
      return res.status(404).json({ error: 'Request not found' });
    }

    request.status = req.body.status;
    await request.save();

    await request.populate([
      { path: 'from', select: 'name email profileImage' },
      { path: 'to', select: 'name email profileImage' },
      { path: 'skill' }
    ]);

    res.json(request);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

module.exports = router;
