const express = require('express');
const Chat = require('../models/Chat');
const auth = require('../middleware/auth');
const router = express.Router();

// Get all chat rooms for a user
router.get('/rooms', auth, async (req, res) => {
  try {
    const chatRooms = await Chat.find({
      participants: req.user._id
    })
    .populate('participants', 'name email profileImage')
    .populate('skill', 'skillName')
    .sort({ lastMessage: -1 });

    res.json(chatRooms);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Get messages for a specific chat room
router.get('/rooms/:roomId/messages', auth, async (req, res) => {
  try {
    const chat = await Chat.findOne({
      _id: req.params.roomId,
      participants: req.user._id
    })
    .populate('messages.sender', 'name email profileImage')
    .select('messages');

    if (!chat) {
      return res.status(404).json({ error: 'Chat room not found' });
    }

    res.json(chat.messages);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Create a new chat room
router.post('/rooms', auth, async (req, res) => {
  try {
    const { participantId, skillId } = req.body;

    // Check if chat room already exists
    const existingChat = await Chat.findOne({
      participants: { $all: [req.user._id, participantId] },
      skill: skillId
    });

    if (existingChat) {
      return res.json(existingChat);
    }

    const chat = new Chat({
      participants: [req.user._id, participantId],
      skill: skillId
    });

    await chat.save();
    
    // Notify the other participant
    req.socketService.io.to(`user:${participantId}`).emit('new_chat', {
      chatId: chat._id,
      userId: req.user._id
    });

    res.status(201).json(chat);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Send a message in a chat room
router.post('/rooms/:roomId/messages', auth, async (req, res) => {
  try {
    const { content } = req.body;
    const chat = await Chat.findOne({
      _id: req.params.roomId,
      participants: req.user._id
    });

    if (!chat) {
      return res.status(404).json({ error: 'Chat room not found' });
    }

    const message = {
      sender: req.user._id,
      content,
      createdAt: new Date()
    };

    chat.messages.push(message);
    chat.lastMessage = new Date();
    await chat.save();

    // Notify other participants
    chat.participants.forEach(participantId => {
      if (participantId.toString() !== req.user._id.toString()) {
        req.socketService.io.to(`user:${participantId}`).emit('new_message', {
          chatRoomId: chat._id,
          message: {
            ...message,
            sender: {
              _id: req.user._id,
              name: req.user.name,
              email: req.user.email,
              profileImage: req.user.profileImage
            }
          }
        });
      }
    });

    res.json(message);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Mark messages as read in a chat room
router.put('/rooms/:roomId/read', auth, async (req, res) => {
  try {
    const chat = await Chat.findOne({
      _id: req.params.roomId,
      participants: req.user._id
    });

    if (!chat) {
      return res.status(404).json({ error: 'Chat room not found' });
    }

    // Mark all unread messages as read
    chat.messages.forEach(message => {
      if (message.sender.toString() !== req.user._id.toString() && !message.read) {
        message.read = true;
      }
    });

    await chat.save();

    // Notify other participants
    chat.participants.forEach(participantId => {
      if (participantId.toString() !== req.user._id.toString()) {
        req.socketService.io.to(`user:${participantId}`).emit('messages_read', {
          chatRoomId: chat._id,
          userId: req.user._id
        });
      }
    });

    res.json({ message: 'Messages marked as read' });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Get unread message counts for all chat rooms
router.get('/unread-counts', auth, async (req, res) => {
  try {
    const chats = await Chat.find({
      participants: req.user._id
    });

    const unreadCounts = chats.map(chat => ({
      chatRoomId: chat._id,
      unreadCount: chat.messages.filter(
        message => 
          message.sender.toString() !== req.user._id.toString() && 
          !message.read
      ).length
    }));

    res.json(unreadCounts);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

module.exports = router;
