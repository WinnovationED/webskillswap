const express = require('express');
const Match = require('../models/Match');
const auth = require('../middleware/auth');
const MatchingService = require('../services/matchingService');
const router = express.Router();

// Get match suggestions
router.get('/suggestions', auth, async (req, res) => {
  try {
    const suggestions = await MatchingService.getMatchSuggestions(req.user._id);
    res.json(suggestions);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Create a match request
router.post('/', auth, async (req, res) => {
  try {
    const { teacherId, skillId } = req.body;
    const match = await MatchingService.createMatchRequest(req.user._id, teacherId, skillId);
    res.status(201).json(match);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Get user's matches
router.get('/', auth, async (req, res) => {
  try {
    const matches = await Match.find({
      $or: [{ user1: req.user._id }, { user2: req.user._id }]
    })
      .populate('user1', 'name email profileImage')
      .populate('user2', 'name email profileImage')
      .populate('skillExchanged')
      .sort({ matchDate: -1 });
    
    res.json(matches);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Update match status
router.patch('/:id', auth, async (req, res) => {
  try {
    const match = await Match.findOne({
      _id: req.params.id,
      user2: req.user._id,
      status: 'pending'
    });

    if (!match) {
      return res.status(404).json({ error: 'Match not found' });
    }

    match.status = req.body.status;
    await match.save();
    res.json(match);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

module.exports = router;
