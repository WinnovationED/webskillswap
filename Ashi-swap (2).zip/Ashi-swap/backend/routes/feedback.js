const express = require('express');
const Feedback = require('../models/Feedback');
const auth = require('../middleware/auth');
const router = express.Router();

// Submit feedback
router.post('/', auth, async (req, res) => {
  try {
    const feedback = new Feedback({
      ...req.body,
      fromUser: req.user._id
    });
    await feedback.save();
    res.status(201).json(feedback);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Get feedback for a user
router.get('/user/:userId', async (req, res) => {
  try {
    const feedback = await Feedback.find({ toUser: req.params.userId })
      .populate('fromUser', 'name email profileImage')
      .sort({ date: -1 });
    res.json(feedback);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

module.exports = router;
