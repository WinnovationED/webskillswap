const express = require('express');
const router = express.Router();
const Chat = require('../models/Chat');
const auth = require('../middleware/auth');

// Get all chats for a user
router.get('/', auth, async (req, res) => {
  try {
    const chats = await Chat.find({
      participants: req.user._id
    })
    .populate('participants', 'name email profileImage')
    .populate('skill')
    .sort({ lastMessage: -1 });
    
    res.json(chats);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get a specific chat
router.get('/:id', auth, async (req, res) => {
  try {
    const chat = await Chat.findOne({
      _id: req.params.id,
      participants: req.user._id
    })
    .populate('participants', 'name email profileImage')
    .populate('skill')
    .populate('messages.sender', 'name email profileImage');
    
    if (!chat) {
      return res.status(404).json({ error: 'Chat not found' });
    }

    // Mark all messages as read
    chat.messages.forEach(message => {
      if (message.sender.toString() !== req.user._id.toString()) {
        message.read = true;
      }
    });
    await chat.save();
    
    res.json(chat);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create or get a chat with another user
router.post('/', auth, async (req, res) => {
  try {
    // Check if chat already exists
    let chat = await Chat.findOne({
      participants: { $all: [req.user._id, req.body.userId] },
      skill: req.body.skillId
    });

    if (!chat) {
      chat = new Chat({
        participants: [req.user._id, req.body.userId],
        skill: req.body.skillId,
        messages: []
      });
      await chat.save();
    }

    await chat.populate([
      { path: 'participants', select: 'name email profileImage' },
      { path: 'skill' }
    ]);

    res.json(chat);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Send a message in a chat
router.post('/:id/messages', auth, async (req, res) => {
  try {
    const chat = await Chat.findOne({
      _id: req.params.id,
      participants: req.user._id
    });

    if (!chat) {
      return res.status(404).json({ error: 'Chat not found' });
    }

    chat.messages.push({
      sender: req.user._id,
      content: req.body.content
    });
    chat.lastMessage = new Date();
    await chat.save();

    await chat.populate([
      { path: 'participants', select: 'name email profileImage' },
      { path: 'skill' },
      { path: 'messages.sender', select: 'name email profileImage' }
    ]);

    res.json(chat);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

module.exports = router;
