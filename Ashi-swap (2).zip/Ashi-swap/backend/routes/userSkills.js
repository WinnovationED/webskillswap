const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const User = require('../models/User');
const Skill = require('../models/Skill');

// Get user's skills (both learning and teaching)
router.get('/user-skills', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user._id)
      .populate('skillsLearned')
      .populate('skillsTaught');

    res.json({
      learning: user.skillsLearned || [],
      teaching: user.skillsTaught || []
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch user skills' });
  }
});

// Update a skill
router.patch('/:skillId', auth, async (req, res) => {
  try {
    const { skillId } = req.params;
    const updates = req.body;
    const allowedUpdates = ['name', 'description', 'proficiencyLevel', 'category', 'tags'];
    
    // Filter out invalid updates
    const validUpdates = Object.keys(updates)
      .filter(key => allowedUpdates.includes(key))
      .reduce((obj, key) => {
        obj[key] = updates[key];
        return obj;
      }, {});

    const skill = await Skill.findOne({
      _id: skillId,
      $or: [
        { creator: req.user._id },
        { teachers: req.user._id }
      ]
    });

    if (!skill) {
      return res.status(404).json({ error: 'Skill not found or unauthorized' });
    }

    Object.assign(skill, validUpdates);
    await skill.save();

    res.json(skill);
  } catch (error) {
    res.status(400).json({ error: 'Failed to update skill' });
  }
});

// Delete a skill
router.delete('/:skillId', auth, async (req, res) => {
  try {
    const { skillId } = req.params;
    const skill = await Skill.findOne({
      _id: skillId,
      $or: [
        { creator: req.user._id },
        { teachers: req.user._id }
      ]
    });

    if (!skill) {
      return res.status(404).json({ error: 'Skill not found or unauthorized' });
    }

    // Remove skill from users' lists
    await User.updateMany(
      { $or: [{ skillsLearned: skillId }, { skillsTaught: skillId }] },
      { 
        $pull: { 
          skillsLearned: skillId,
          skillsTaught: skillId
        }
      }
    );

    await skill.remove();
    res.json({ message: 'Skill deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete skill' });
  }
});

// Add skill to user's learning or teaching list
router.post('/user-skills', auth, async (req, res) => {
  try {
    const { skillId, action } = req.body;
    const user = await User.findById(req.user._id);
    const skill = await Skill.findById(skillId);

    if (!skill) {
      return res.status(404).json({ error: 'Skill not found' });
    }

    if (action === 'learn') {
      if (!user.skillsLearned.includes(skillId)) {
        user.skillsLearned.push(skillId);
        skill.learners.push(user._id);
      }
    } else if (action === 'teach') {
      if (!user.skillsTaught.includes(skillId)) {
        user.skillsTaught.push(skillId);
        skill.teachers.push(user._id);
      }
    }

    await Promise.all([user.save(), skill.save()]);
    res.json({ message: 'Skill updated successfully' });
  } catch (error) {
    res.status(400).json({ error: 'Failed to update skill' });
  }
});

// Remove skill from user's learning or teaching list
router.delete('/user-skills/:skillId/:action', auth, async (req, res) => {
  try {
    const { skillId, action } = req.params;
    const user = await User.findById(req.user._id);
    const skill = await Skill.findById(skillId);

    if (!skill) {
      return res.status(404).json({ error: 'Skill not found' });
    }

    if (action === 'learn') {
      user.skillsLearned = user.skillsLearned.filter(id => id.toString() !== skillId);
      skill.learners = skill.learners.filter(id => id.toString() !== user._id.toString());
    } else if (action === 'teach') {
      user.skillsTaught = user.skillsTaught.filter(id => id.toString() !== skillId);
      skill.teachers = skill.teachers.filter(id => id.toString() !== user._id.toString());
    }

    await Promise.all([user.save(), skill.save()]);
    res.json({ message: 'Skill removed successfully' });
  } catch (error) {
    res.status(400).json({ error: 'Failed to remove skill' });
  }
});

module.exports = router;
