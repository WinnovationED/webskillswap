const express = require('express');
const router = express.Router();
const axios = require('axios');

// Replace with your actual API key and organization
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;

router.post('/generate-images', async (req, res) => {
  try {
    const { prompt, n = 1 } = req.body;

    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required' });
    }

    const response = await axios.post(
      'https://api.openai.com/v1/images/generations',
      {
        prompt,
        n,
        size: '512x512',
        response_format: 'url',
      },
      {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${OPENAI_API_KEY}`,
        },
      }
    );

    const images = response.data.data.map(item => item.url);
    res.json({ images });
  } catch (error) {
    console.error('Error generating images:', error);
    res.status(500).json({ error: 'Failed to generate images' });
  }
});

module.exports = router;
