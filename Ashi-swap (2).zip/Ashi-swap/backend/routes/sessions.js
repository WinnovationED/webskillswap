const express = require('express');
const router = express.Router();
const sessionController = require('../controllers/sessionController');
const auth = require('../middleware/auth');

// Create a new session
router.post('/', auth, sessionController.createSession);

// Get all sessions (with filters)
router.get('/', auth, sessionController.getSessions);

// Get upcoming sessions
router.get('/upcoming', auth, sessionController.getUpcomingSessions);

// Search sessions
router.get('/search', auth, sessionController.searchSessions);

// Get specific session
router.get('/:id', auth, sessionController.getSessionById);

// Join a session
router.post('/:id/join', auth, sessionController.joinSession);

// Update participant status
router.patch('/:id/participants/:userId', auth, sessionController.updateParticipantStatus);

// Add material to session
router.post('/:id/materials', auth, sessionController.addMaterial);

// Add feedback to session
router.post('/:id/feedback', auth, sessionController.addFeedback);

// Cancel session
router.patch('/:id/cancel', auth, sessionController.cancelSession);

module.exports = router;
